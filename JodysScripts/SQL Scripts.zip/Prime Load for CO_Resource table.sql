USE PIV_Reports
--drop table #Temp
/*
select bc.Description
from dbo.tblResource r
join dbo.lkBillingCode bc
	on r.Billing_CodeID = bc.Billing_CodeID
where r.StatusCode = 'A'
group by bc.Description
order by Description

select * from dbo.CO_BillingCode
*/

--truncate table dbo.CO_Resource

Insert dbo.CO_Resource
--select * into #TEMP_IN from dbo.SP_Get_CO_Estimate_Tracking_Summary_View
select --Top 100
		 r.ResourceNumber
--		,r.StatusCode
--		,r.EDSJobCode
--		,bc.Description As PIV_Billing_Code_Desc
--		,r.Region_Geog
		,CASE Description
			WHEN 'Junior SE'			THEN '3000'
			WHEN 'Junior SE TPF'		THEN '3000'
			WHEN 'SE'					THEN '3001'
			WHEN 'SE TPF'				THEN '3001'
			WHEN 'Advanced SE'			THEN '3002'
			WHEN 'Advanced SE TPF'		THEN '3002'
			WHEN 'Senior SE'			THEN '3003'
			WHEN 'Senior SE TPF'		THEN '3003'
			WHEN 'Project Leader'		THEN '3005'
			WHEN 'Project Leader TPF'	THEN '3005'
			WHEN 'Project Manager'		THEN '3006'
         ELSE Null
	     END as Billing_Code_ID
		,r.LastName
		,r.FirstName
		,r.MI
--		,r.ResourceOrg
		,CASE r.ResourceOrg
			WHEN 'BSSC INDIA'				THEN 'False'
			WHEN 'AD-BR-RIO ADU'			THEN 'False'
			WHEN 'BSSC CHINA'				THEN 'False'
			WHEN 'AD-MX-JUAREZ ADU'			THEN 'False'
			WHEN 'AD-MX-MEXICO CITY'		THEN 'False'
			WHEN 'AD-BR-SAO PAULO ADU'		THEN 'False'
			WHEN 'BSSC SYDNEY'				THEN 'False'
			WHEN 'MEXICO CITY SOLUTION CENTRE' THEN 'False'
			WHEN 'AD-AR ARGENTINA ADU'		THEN 'False'
			WHEN 'INDIA SC'					THEN 'False'
		 ELSE 'True'
	     END as Onshore
		,CASE r.ResourceOrg
			WHEN 'BSSC INDIA'				THEN 'True'
			WHEN 'AD-BR-RIO ADU'			THEN 'True'
			WHEN 'BSSC CHINA'				THEN 'True'
			WHEN 'AD-MX-JUAREZ ADU'			THEN 'True'
			WHEN 'AD-MX-MEXICO CITY'		THEN 'True'
			WHEN 'AD-BR-SAO PAULO ADU'		THEN 'True'
			WHEN 'BSSC SYDNEY'				THEN 'True'
			WHEN 'MEXICO CITY SOLUTION CENTRE' THEN 'True'
			WHEN 'AD-AR ARGENTINA ADU'		THEN 'True'
			WHEN 'INDIA SC'					THEN 'True'
		 ELSE 'False'
	     END as Offshoure
		,'False'	as Hourly
		,Getdate()	as LastUpdateDate
--Into #Temp
from dbo.tblResource r
join dbo.lkBillingCode bc
	on r.Billing_CodeID = bc.Billing_CodeID
where r.StatusCode = 'A'
and bc.Description In (	
	'Advanced SE', 'Advanced SE TPF', 'Junior SE', 'Junior SE TPF', 'Project Leader', 'Project Leader TPF', 'Project Manager', 
	'SE', 'SE TPF', 'Senior SE', 'Senior SE TPF')
--order by Billing_CodeID, Description
--order by Description
order by r.ResourceOrg

/*
select	t.*,
		bc.Description as CO_Billing_Code_Desc
from #Temp t
join dbo.CO_BillingCode bc
	on t.CO_Billing_Code_ID = bc.Billing_CodeID


select	r.ResourceNumber,
		bc.Description,
		r.LastName,
		r.FirstName,
		r.MI,
		r.Onshore,
		r.Offshore,
		r.Hourly,
		r.LastUpdateDate
from CO_Resource r
Join CO_BillingCode bc
	on r.Billing_CodeID = bc.Billing_CodeID
*/
--select * from dbo.tblResource r
--select * from dbo.CO_BillingCode cobc