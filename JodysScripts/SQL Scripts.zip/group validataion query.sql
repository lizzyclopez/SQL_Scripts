Use PIV_Reports

Select	RequestCODivision					As CODivision,
		RequestCOSubDivision				As COSubDivision,
		RequestSummary						As RequestSummary,
		RequestExternalRef					As RequestNumber,
		RequestID							As AldeaRequestNumber,
		RequestType							As RequestType,
		RequestCORequestor					As CORequestor,
		RequestDeliveryLeader				As EDSDeliveryLead,
		RequestTower						As Tower,
		RequestApplication					As [Application],
		RequestRequesterPriority			As Priority,
		RequestRank							As Rank,
		RequestEstimatedHoursCurrent		As ApprovedEstHours,
		40									As LastMonthPTDHours,
		30									As MonthlyActualHours,
		10									As OnshoreHours,
		20									As OffshoreHours,
		50									As CurrentPTDHours,
		20									As CurrentPTDOnshoreHours,
		30									As CurrentPTDffnshoreHours,
		RequestCOStatus						As Status,
		RequestOriginationDate				As DateReqeustReceived,
		RequestDatesEDSAcknowledge			As DateReqeustAcknowledge,
		RequestDatesEstimateSubmitted		As DateEstimateSubmitted,
		RequestDatesTargetImplementation	As DateRequestCompleteAgreed,
		RequestDatesActualImplementation	As DateRequestActualComplete
		
From	dbo.Aldea_Data
Order By RequestCODivision ASC, RequestCOSubDivision ASC, RequestSummary ASC

