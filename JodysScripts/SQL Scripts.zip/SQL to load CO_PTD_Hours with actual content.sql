drop table ##CO_Estimate_Tracking_Summary

Declare @DateFrom datetime
Set @DateFrom = '04/01/2008'

Declare @DateTo datetime
Set @DateTo= '04/30/2008'

Declare @CurrentMonth varchar(6) 
Set @CurrentMonth = '200804'

Declare @SolutionCentreList varchar(500)
Set @SolutionCentreList = '-1'

Declare @CODivisionList varchar(500)
Set @CODivisionList = '-1'

Declare @DeliveryLeadList varchar(500)
Set @DeliveryLeadList = '-1'

Declare @COStatusList varchar(500)
Set @COStatusList = '-1'

Declare @CORequestorList varchar(500)
Set @CORequestorList = '-1'

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Execute the Estimate Tracking Summary report to accumulate the hours for the month
	EXEC Get_CO_Estimate_Tracking_Summary 
		@DateFrom,
		@DateTo,
		@CurrentMonth,
		@SolutionCentreList,
		@CODivisionList,
		@DeliveryLeadList,
		@COStatusList,
		@CORequestorList,
		@OutputTable = '##CO_Estimate_Tracking_Summary'

	-- Insert the total hours from the Estimate Tracking Report to the CO_PTD_Hours table
	Insert Into CO_PTD_Hours
	Select	 AldeaRequestNumber As RequestID
			,@DateTo As SummaryDate
			,OnshoreHours As OnshoreTotalHours
			,OffshoreHours As OffshoreTotalHours
			,GetDate() As LastUpdateDate
	From	##CO_Estimate_Tracking_Summary
	Where	RecNumber = 30
	And		OnshoreHours + OffshoreHours > 0

	order by AldeaRequestNumber
	-- Check to see if the PTD locking date exists.
	-- If it does not, insert the new locking date.
	-- If it does, update with the new locking date.
/*
    IF (SELECT COUNT(*) FROM CO_PTD_LockInDate) = 0
	 BEGIN
		INSERT CO_PTD_LockInDate
			VALUES(@DateTo)
	 END
	Else
	 BEGIN
		UPDATE CO_PTD_LockInDate
        SET FromDate = @DateTo
	 END
*/


