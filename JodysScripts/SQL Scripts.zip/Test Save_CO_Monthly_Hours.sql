
drop table ##CO_Estimate_Tracking_Summary

exec Save_CO_Monthly_Hours
	@DateFrom = '03/01/2008',
	@DateTo = '03/31/2008',
	@CurrentMonth = '200803'

select *
from CO_PTD_Hours
order by RequestID, SummaryDate Desc

select *
from CO_PTD_LockInDate

/*
delete from CO_PTD_Hours
where SummaryDate = '2008-03-31 00:00:00.000'


UPDATE CO_PTD_LockInDate
SET FromDate = '02/29/2008'
*/
