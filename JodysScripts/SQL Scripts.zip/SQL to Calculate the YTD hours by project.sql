drop table #TEMP_IN
drop table #TEMP_IN2
drop table #TEMP_OUT

	Use PIV_Reports

	-- =============================================
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @DateFrom datetime
	SET @DateFrom = '04/01/2008'

	DECLARE @DateTo datetime
	SET @DateTo = '04/30/2008'

	DECLARE @CurrentMonth varchar(6)
	SET @CurrentMonth = '200805'
	SET @CurrentMonth = Null

	DECLARE @CODivisionList varchar(500)
	SET @CODivisionList = '-1'

	DECLARE @DeliveryLeadList varchar(500)
	SET @DeliveryLeadList = '-1'

	DECLARE @COStatusList varchar(500)
	SET @COStatusList = '-1'

	DECLARE @CORequestorList varchar(500)
	SET @CORequestorList = '-1'

	DECLARE @OutputTable varchar(30)
	SET @OutputTable = NULL

	--Default the From and To Dates
	if ( @DateFrom is NULL )
		Set @DateFrom = '2000-01-01'
	if ( @DateTo is NULL )
		Set @DateTo = GetDate()

	-- Declare the needed common variables.
	Declare @SQL_statement varchar(1000), @row_count int, @Factor decimal(5,2)
	set @SQL_statement = ''

	Declare @AldeaRequestNumber int
	Declare @PTDHours decimal(10,2)
	Declare @LastMnthHrsOnShore decimal(10,2)
	Declare @LastMnthHrsOffShore decimal(10,2)
	Declare @ThisMnthHrsOnShore decimal (10,2)
	Declare @ThisMnthHrsOffShore decimal (10,2)

	-- Prepare the SQL WHERE clause for the new VIEW
	if ( @CODivisionList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and CODivision in ('+@CODivisionList+')'
	if ( @DeliveryLeadList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and EDSDeliveryLead in ('+@DeliveryLeadList+')'
	if ( @CORequestorList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and CORequestor in ('+@CORequestorList+')'
	if ( @COStatusList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and Status in ('+@COStatusList+')'

	-- Drop the temp VIEW if it exists
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_Get_CO_Estimate_Tracking_Summary_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[SP_Get_CO_Estimate_Tracking_Summary_View]

	-- Build the new VIEW
	set @SQL_statement = 'Create View dbo.SP_Get_CO_Estimate_Tracking_Summary_View AS select * from CO_Estimate_Tracking_Summary_View where 1=1 ' + @SQL_statement

	--print '--- VIEW dbo.SP_Get_CO_Estimate_Tracking_Summary_View ---'
	--print @SQL_statement
	exec (@SQL_statement)

	select * into #TEMP_IN from dbo.SP_Get_CO_Estimate_Tracking_Summary_View
	exec('Drop View dbo.SP_Get_CO_Estimate_Tracking_Summary_View')

	-- Alter table definition
	ALTER TABLE #TEMP_IN ADD PTDHours decimal(7,2) NULL
	ALTER TABLE #TEMP_IN ADD LastMonthHoursOnShore decimal(7,2) NULL
	ALTER TABLE #TEMP_IN ADD LastMonthHoursOffShore decimal(7,2) NULL
	ALTER TABLE #TEMP_IN ADD ThisMonthHoursOnShore decimal(7,2) NULL
	ALTER TABLE #TEMP_IN ADD ThisMonthHoursOffShore decimal(7,2) NULL

	-- Index the #TEMP_IN table
	Create Index IDX1 on #TEMP_IN (CODivision, COSubDivision, AldeaRequestNumber)

	-- Build the where statement for the call to join Aldea Data and Actual time worked
	set @SQL_statement = ''
	if ( @CurrentMonth is not NULL )
		select @SQL_statement = @SQL_statement+' and CurrentMonth = '+@CurrentMonth

	-- Drop the second temp VIEW if it exists.
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_Get_CO_Estimate_Tracking_Summary_View2]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[SP_Get_CO_Estimate_Tracking_Summary_View2]

	-- Create the second temp VIEW
	set @SQL_statement = 'Create View dbo.SP_Get_CO_Estimate_Tracking_Summary_View2 AS select * from CO_Actual_Hours_Worked h where Hours > 0 ' + @SQL_statement
	exec (@SQL_statement)
	
	--print '--- VIEW dbo.SP_Get_CO_Estimate_Tracking_Summary_View2 ---'
	--print @SQL_statement
	select * into #TEMP_IN2 from dbo.SP_Get_CO_Estimate_Tracking_Summary_View2

	-- Drop the second temp VIEW
	exec('Drop View dbo.SP_Get_CO_Estimate_Tracking_Summary_View2')

	-- Adjust the Hours according to the ClientFundingPct by CO
	Update #TEMP_IN2
	Set Hours = IsNull(ProjectClientFundingPct, 100) / 100 * Hours
	Where IsNull(ProjectClientFundingPct, 0) > 0

	-- Adjust the Hours according to the TaskClientFundingPct by CO
	Update #TEMP_IN2
	Set Hours = IsNull(TaskClientFundingPct, 100) / 100 * Hours
	Where IsNull(TaskClientFundingPct, 0) > 0

	-- Populate each CODivision into the output table
	DECLARE AldeaRequest_cursor CURSOR FOR 
		select distinct AldeaRequestNumber from #TEMP_IN
		order by 	AldeaRequestNumber
	OPEN AldeaRequest_cursor
	FETCH NEXT FROM AldeaRequest_cursor INTO @AldeaRequestNumber
		WHILE @@FETCH_STATUS = 0
		BEGIN
			-- Sum up the Hours for each project
			Select	@PTDHours = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		WorkDate < @DateFrom

			-- Find last months OnShore PTD hours
			Select	@LastMnthHrsOnShore = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		WorkDate >= @DateFrom
			And		WorkDate <=	@DateTo
			And		Onshore = 1

			-- Find last months OffShore PTD hours
			Select	@LastMnthHrsOffShore = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		WorkDate >= @DateFrom
			And		WorkDate <=	@DateTo
			And		Offshore = 1

			-- Find this months OnShore PTD hours
			Select	@ThisMnthHrsOnShore = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		WorkDate > @DateTo
			And		Onshore = 1

			-- Find this months OnShore PTD hours
			Select	@ThisMnthHrsOffShore = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		WorkDate > @DateTo
			And		Offshore = 1

			-- select * from #TEMP_IN
			-- Update the temporary table for the current Onshore Hours
			Update	#TEMP_IN
			Set		PTDHours = IsNull(@PTDHours, 0),
					LastMonthHoursOnShore = IsNull(@LastMnthHrsOnShore, 0),
					LastMonthHoursOffShore = IsNull(@LastMnthHrsOffShore, 0),
					ThisMonthHoursOnShore = IsNull(@ThisMnthHrsOnShore, 0),
					ThisMonthHoursOffShore = IsNull(@ThisMnthHrsOffShore, 0)
			Where	AldeaRequestNumber = @AldeaRequestNumber

			FETCH NEXT FROM AldeaRequest_cursor INTO @AldeaRequestNumber
		END    
	CLOSE AldeaRequest_cursor
	DEALLOCATE AldeaRequest_cursor

	-- Create the output table #TEMP_OUT
	CREATE TABLE [dbo].[#TEMP_OUT] ( 
		[AutoKey][int] IDENTITY (0, 1) NOT NULL,
		[RecNumber][int] NULL,
		[RecType] [varchar] (255) NULL, -- CODivision / Program / SummaryDesc / Total / FTE Conversion
		[RecDesc] [varchar] (255) NULL,
		[RequestNumber] [varchar] (255) NULL,
		[AldeaRequestNumber] [varchar] (255) NULL,
		[RequestType] [varchar] (255) NULL,
		[CORequestor] [varchar] (255) NULL,
		[EDSDeliveryLead] [varchar] (255) NULL,
		[Tower] [varchar] (255) NULL,
		[Application] [varchar] (255) NULL,
		[Priority] [int] NULL,
		[Rank] [int] NULL,
		[ApprovedEstHours] [float] Null,
		[PTDHours] [float] NULL,
		[LastMonthHoursOnShore] [float] NULL,
		[LastMonthHoursOffShore] [float] NULL,
		[ThisMonthHoursOnShore] [float] NULL,
		[ThisMonthHoursOffShore] [float] NULL,
		[Status] [varchar] (255) NULL,
		[DateReqeustReceived] [varchar] (2000) NULL,
		[DateReqeustAcknowledge] [varchar] (2000) Null,
		[DateEstimateSubmitted] [varchar] (2000) Null,
		[DateRequestCompleteAgreed] [varchar] (2000) Null,
		[DateRequestActualComplete] [varchar] (2000) Null,
		[R10_CODivision] [varchar] (255) NULL,
		[R20_COSubDivision] [varchar] (255) NULL
	) ON [PRIMARY]

	-- Check to see if we have data to process
	select @row_count = count(*) from #TEMP_IN
	if @row_count = 0
	begin
		insert #TEMP_OUT (RecNumber) values (99)
		goto No_Data_To_Process
	end

	-- Data was found
	-- Declare additional needed fields.
	DECLARE @CurCODivision varchar(255), --, @CurProg_GroupID int, 
			@CurCOSubDivision varchar(255), --, @CurProgramID  int, @CurCOBusinessLead varchar (100),
			@CurSummaryDesc varchar (255), @CurAldeaRequestNumber int
	DECLARE @MaxDivisionGroup int, @MaxCOSubDivision int, @MaxSummaryDesc int, @MaxProj bigint

	---------------------------------------------------------------------------------------------------
	-- Populate each CODivision into the output table
	DECLARE CODivision_cursor CURSOR FOR 
		select distinct CODivision from #TEMP_IN
		where CODivision is not null
		order by 	CODivision
	OPEN CODivision_cursor
	FETCH NEXT FROM CODivision_cursor INTO @CurCODivision
		WHILE @@FETCH_STATUS = 0
		BEGIN
			insert #TEMP_OUT (RecNumber) values (10) -- A blank line
			insert #TEMP_OUT (RecNumber, RecType, RecDesc)
 			select 10, 'CODivision', @CurCODivision
			select @MaxDivisionGroup = max(AutoKey) from #TEMP_OUT

	---------------------------------------------------------------------------------------------------
			-- Populate each COSubDivision into the output table
			DECLARE COSubDivision_cursor CURSOR FOR 
				select distinct COSubDivision from #TEMP_IN
				where CODivision = @CurCODivision and COSubDivision is not null
				order by COSubDivision
	            
			OPEN COSubDivision_cursor
			FETCH NEXT FROM COSubDivision_cursor INTO @CurCOSubDivision
        		WHILE @@FETCH_STATUS = 0
				BEGIN
        			insert #TEMP_OUT (RecNumber, RecType, RecDesc, R10_CODivision)
					select 20, 'COSubDivision', @CurCOSubDivision, @CurCODivision
					select @MaxCOSubDivision = max(AutoKey) from #TEMP_OUT

	---------------------------------------------------------------------------------------------------                
					-- Populate each Summary Desc into the output table.
					DECLARE SummaryDesc_cursor CURSOR FOR 
						select distinct RequestSummary, AldeaRequestNumber from #TEMP_IN
						where CODivision = @CurCODivision and COSubDivision = @CurCOSubDivision and AldeaRequestNumber is not null
						order by RequestSummary
					OPEN SummaryDesc_cursor
					FETCH NEXT FROM SummaryDesc_cursor INTO @CurSummaryDesc, @CurAldeaRequestNumber
						WHILE @@FETCH_STATUS = 0
        					BEGIN
        						insert #TEMP_OUT (RecNumber, RecType, RecDesc, AldeaRequestNumber ,R10_CODivision, R20_COSubDivision)
           		   				select 30, 'SummaryDesc', @CurSummaryDesc, @CurAldeaRequestNumber, @CurCODivision, @CurCOSubDivision
								select @MaxSummaryDesc = max(AutoKey) from #TEMP_OUT
								update #TEMP_OUT
								set RequestNumber 		= (select RequestNumber from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									RequestType 		= (select RequestType from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									CORequestor	 		= (select CORequestor from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									EDSDeliveryLead		= (select EDSDeliveryLead from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									Tower				= (select Tower from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									[Application] 		= (select [Application] from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									Priority 			= (select Priority from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									Rank	 			= (select Rank from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									ApprovedEstHours 	= (select ApprovedEstHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									PTDHours			= (select PTDHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),

									LastMonthHoursOnShore  = (select LastMonthHoursOnShore from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									LastMonthHoursOffShore = (select LastMonthHoursOffShore from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									ThisMonthHoursOnShore  = (select ThisMonthHoursOnShore from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									ThisMonthHoursOffShore = (select ThisMonthHoursOffShore from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),

									Status 					= (select Status from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									DateReqeustReceived 	= (select DateReqeustReceived from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									DateReqeustAcknowledge 	= (select DateReqeustAcknowledge from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									DateEstimateSubmitted 	= (select DateEstimateSubmitted from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									DateRequestCompleteAgreed 	= (select DateRequestCompleteAgreed from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
									DateRequestActualComplete 	= (select DateRequestActualComplete from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)
								where AutoKey = @MaxSummaryDesc					-- Update output table with record detail
					FETCH NEXT FROM SummaryDesc_cursor INTO @CurSummaryDesc, @CurAldeaRequestNumber
					END    
				CLOSE SummaryDesc_cursor
				DEALLOCATE SummaryDesc_cursor
	---------------------------------------------------------------------------------------------------
				FETCH NEXT FROM COSubDivision_cursor INTO @CurCOSubDivision
				END
			CLOSE COSubDivision_cursor
			DEALLOCATE COSubDivision_cursor
	---------------------------------------------------------------------------------------------------
			FETCH NEXT FROM CODivision_cursor INTO @CurCODivision
			END
		CLOSE CODivision_cursor
		DEALLOCATE CODivision_cursor
	---------------------------------------------------------------------------------------------------
	No_Data_To_Process:
	SET NOCOUNT OFF

	-- Output the result
	Select	--RecNumber,
--			IsNull(Cast(RecType as varchar(2000)),'') as RecType, 
--			IsNull(Cast(RecDesc as varchar(2000)),'') as RecDesc, 
--			IsNull(Cast(RequestNumber as varchar(2000)),'') as ClientRequestNumber, 
			IsNull(Cast(AldeaRequestNumber as varchar(2000)),'') as AldeaRequestNumber, 
--			IsNull(Cast(RequestType as varchar(2000)),'') as RequestType, 
--			IsNull(Cast(CORequestor as varchar(2000)),'') as CORequestor, 
--			IsNull(Cast(EDSDeliveryLead as varchar(2000)),'') as EDSDeliveryLead, 
--			IsNull(Cast(Tower as varchar(2000)),'') as Tower, 
--			IsNull(Cast([Application] as varchar(2000)),'') as Application, 
--			IsNull(Cast(Priority as varchar(2000)),'') as Priority, 
--			IsNull(Cast(Rank as varchar(2000)),'') as Rank, 
--			IsNull(Cast(ApprovedEstHours as varchar(2000)),'') as ApprovedEstHours, 
			IsNull(Cast(PTDHours as varchar(2000)),'') as HrsBeforeApril1,
			IsNull(Cast(LastMonthHoursOnShore as varchar(2000)),'') as HrsInAprilOnShore, 
			IsNull(Cast(LastMonthHoursOffShore as varchar(2000)),'') as HrsInAprilOffShore
--			IsNull(Cast(ThisMonthHoursOnShore as varchar(2000)),'') as HrsInMayOnShore,
--			IsNull(Cast(ThisMonthHoursOffShore as varchar(2000)),'') as HrsInMayOffShore
--			IsNull(Cast(Status as varchar(2000)),'') as Status, 
--			IsNull(Cast(DateReqeustReceived as varchar(2000)),'') as DateReqeustReceived, 
--			IsNull(Cast(DateReqeustAcknowledge as varchar(2000)),'') as DateReqeustAcknowledge, 
--			IsNull(Cast(DateEstimateSubmitted as varchar(2000)),'') as DateEstimateSubmitted, 
--			IsNull(Cast(DateRequestCompleteAgreed as varchar(2000)),'') as DateRequestCompleteAgreed, 
--			IsNull(Cast(DateRequestActualComplete as varchar(2000)),'') as DateRequestActualComplete 
	From   #TEMP_OUT
	Where RecNumber = 30
	And PTDHours + LastMonthHoursOnShore + LastMonthHoursOffShore > 0
	Order by AldeaRequestNumber

--	Order By AutoKey
