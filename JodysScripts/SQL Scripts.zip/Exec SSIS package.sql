declare @result int

--- Check last 2 hours for successful DTS.
--if not exists (select * from PIV_Import..Log where TS > dateadd(hh, -2, getdate()) and Text like '%3-1 DTS ProjectDataCO.mdb - Ended%' )
--begin
	exec xp_cmdshell 'dtexec /f "f:\Applications\PIV_Transfer\SSIS Package - Import Aldea data.dtsx"'

	exec @result = xp_cmdshell 'dtexec /f "f:\Applications\PIV_Transfer\SSIS Package - Import Aldea data.dtsx"'

	if @result = 0
		insert into PIV_Import..Log ( StatusCode, ProcessName, Text) values( 'I', 'SSIS - Import Aldea data into R2', 'SSIS - Import Aldea data into R2 - Ended At '+convert(varchar(25), getdate(),120))
	else
	begin
		insert into PIV_Import..Log ( StatusCode, ProcessName, Text) values( 'E', 'SSIS - Import Aldea data into R2', 'SSIS - Import Aldea data into R2 - Failed')
		--exec piv_import..sp_sendnotification 'lizzy.lopez@eds.com', 'lizzy.lopez@eds.com','R2 AM-Load Failed!','SSIS - Import Aldea data into R2 - 5:00AM'
		--exec piv_import..sp_sendnotification 'lizzy.lopez@eds.com', '8662346717@skytel.com','R2 AM-Load Failed!','SSIS - Import Aldea data into R2 - 5:00AM'
	end
--end

