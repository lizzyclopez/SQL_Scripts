










/*
TRUNCATE TABLE [Aldea_Import].[dbo].[AldeaExtract]
GO

Insert into [Aldea_Import].[dbo].[AldeaExtract]
select *
from [Aldea_Import].[dbo].[Load_Aldea_Data_View]
GO
*/

--select distinct RequestOwner from dbo.AldeaExtract
--select distinct RequestOwnerOrg from dbo.AldeaExtract
--select distinct RequestRespUser from dbo.AldeaExtract
--select distinct RequestRespOrg from dbo.AldeaExtract
--select distinct RequestType from dbo.AldeaExtract
--select distinct RequestSummary from dbo.AldeaExtract
--select distinct RequestStatus from dbo.AldeaExtract
--select distinct RequestDetailText from dbo.AldeaExtract
--select distinct RequestRequesterPriority from dbo.AldeaExtract
--if (select distinct count(*) from dbo.AldeaExtract where RequestRank Is Null) > 0
--  update dbo.AldeaExtract set RequestRank = 0 where RequestRank Is Null
--if (select distinct count(*) from dbo.AldeaExtract where RequestExternalRef Is Null) > 0
--  update dbo.AldeaExtract set RequestExternalRef = 0 where RequestExternalRef Is Null
--select distinct RequestRequestedCompletionDate from dbo.AldeaExtract
--select distinct RequestOriginationDate from dbo.AldeaExtract
--if (select distinct count(*) from dbo.AldeaExtract where RequestCODivision = '(None)') > 0
--  update dbo.AldeaExtract set RequestCODivision = Null where RequestCODivision = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where RequestCOSubDivision = '(None)') > 0
--  update dbo.AldeaExtract set RequestCOSubDivision = Null where RequestCOSubDivision = '(None)'
--select distinct RequestApplication from dbo.AldeaExtract
--if (select distinct count(*) from dbo.AldeaExtract where RequestTower = '(None)') > 0
--  update dbo.AldeaExtract set RequestTower = Null where RequestTower = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where RequestCORequestor = '(None)') > 0
--  update dbo.AldeaExtract set RequestCORequestor = Null where RequestCORequestor = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where RequestProgrammeManager = '(None)') > 0
--  update dbo.AldeaExtract set RequestProgrammeManager = Null where RequestProgrammeManager = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where RequestDeliveryLeader = '(None)') > 0
--  update dbo.AldeaExtract set RequestDeliveryLeader = Null where RequestDeliveryLeader = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where RequestPMorTeamLead = '(None)') > 0
--  update dbo.AldeaExtract set RequestPMorTeamLead = Null where RequestPMorTeamLead = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where RequestTotalActualHours Is Null) > 0
--  update dbo.AldeaExtract set RequestTotalActualHours = '0' where RequestTotalActualHours Is Null
--if (select distinct count(*) from dbo.AldeaExtract where RequestCOStatus = '(None)') > 0
--  update dbo.AldeaExtract set RequestCOStatus = Null where RequestCOStatus = '(None)'


--if (select distinct count(*) from dbo.AldeaExtract where [Request Dates Actual Implementation] = '(None)') > 0
--	update dbo.AldeaExtract set [Request Dates Actual Implementation] = Null where [Request Dates Actual Implementation] = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where [Request Dates Target Implementation] = '(None)') > 0
--	update dbo.AldeaExtract set [Request Dates Target Implementation] = Null where [Request Dates Target Implementation] = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where [Request Dates Estimate Submitted] = '(None)') > 0
--	update dbo.AldeaExtract set [Request Dates Estimate Submitted] = Null where [Request Dates Estimate Submitted] = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where [Request Dates EDS Acknowledge] = '(None)') > 0
--	update dbo.AldeaExtract set [Request Dates EDS Acknowledge] = Null where [Request Dates EDS Acknowledge] = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where [Request Estimated Hours Orig] = '(None)') > 0
--  update dbo.AldeaExtract set [Request Estimated Hours Orig] = Null where [Request Estimated Hours Orig] = '(None)'
--if (select distinct count(*) from dbo.AldeaExtract where [Request Estimated Hours Current] = '(None)') > 0
--  update dbo.AldeaExtract set [Request Estimated Hours Current] = Null where [Request Estimated Hours Current] = '(None)'




/*
RequestDatesTargetImplementation
RequestChangeLogNotes
*/


