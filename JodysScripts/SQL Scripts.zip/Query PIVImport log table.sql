USE PIV_Import

select *
from Log
where TS > '05/24/2008'
and text like '%Aldea%'
order by TS desc