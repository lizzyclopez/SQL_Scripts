/*
-- This is the FTE_Approved_Time view
SELECT    dbo.lkAFEDescription.Description AS AFEDesc
		, dbo.lkProgram.Description AS Program
		, dbo.lkProgramGroup.Description AS ProgramGroup
		, dbo.tblAFEDetail.Prog_GroupID
		, dbo.tblAFEDetail.ProgramID
		, SUM(dbo.tblStaffingPlanDetail.FTE_frcst_mo1) AS Appr_FTE_Hours
		, dbo.tblStaffingPlanDetail.CurrentMonth
		, dbo.tblStaffingPlanDetail.AFE_DescID
		, dbo.tblAFEDetail.Funding_CatID
		, dbo.lkProgram.COBusinessLead
FROM		dbo.lkAFEDescription 
INNER JOIN	dbo.tblAFEDetail 
				ON dbo.lkAFEDescription.AFE_DescID = dbo.tblAFEDetail.AFE_DescID 
INNER JOIN	dbo.lkProgram 
				ON dbo.tblAFEDetail.ProgramID = dbo.lkProgram.ProgramID 
INNER JOIN	dbo.lkProgramGroup 
				ON dbo.tblAFEDetail.Prog_GroupID = dbo.lkProgramGroup.Prog_GroupID 
RIGHT OUTER JOIN dbo.tblStaffingPlanDetail 
				ON dbo.tblAFEDetail.AFE_DescID = dbo.tblStaffingPlanDetail.AFE_DescID

Where CurrentMonth = '200804'

GROUP BY	dbo.lkAFEDescription.Description, 
			dbo.lkProgram.Description, 
			dbo.lkProgramGroup.Description, 
			dbo.tblAFEDetail.Prog_GroupID, 
            dbo.tblAFEDetail.ProgramID,		
			dbo.tblStaffingPlanDetail.CurrentMonth, 
			dbo.tblStaffingPlanDetail.AFE_DescID, 
			dbo.tblAFEDetail.Funding_CatID, 
            dbo.lkProgram.COBusinessLead
*/

SELECT		Top 30
			a.RequestID,
			a.RequestSummary,
			h.ResourceNumber,
			h.WorkDate,
			h.CurrentMonth,
			h.Hours,
			h.Onshore,
			h.Offshore,
			h.Hourly
FROM		dbo.Aldea_Data a
INNER JOIN	CO_Actual_Hours_Worked h
				ON a.RequestID = h.AldeaRequestId


/*
-- This is the CO_Actual_Hours_Worked
Select		t.Text14 AS AldeaRequestId,	
			t.ProjectID,
			t.TaskID,
			t.Name AS TaskName,
			t.TaskNumber,
			rd.WorkDate,
			Cast(Year(rd.WorkDate) As Char(4)) + Right(STR(Month(rd.WorkDate) + 100, 3), 2) As CurrentMonth,
			rd.Hours,
			rd.ResourceNumber,
			r.Billing_CodeID,
			r.Onshore,
			r.Offshore,
			r.Hourly
From		dbo.tblTask t
INNER JOIN  dbo.tblResourceDetail rd
				ON t.ProjectID = rd.ProjectID AND t.TaskID = rd.TaskID
INNER JOIN	dbo.CO_Resource r
				ON rd.ResourceNumber = r.ResourceNumber

Where t.Text14 is not Null
*/
/*
select *
from dbo.tblResourceDetail rd
join dbo.CO_Resource r
	On rd.ResourceNumber = r.ResourceNumber
where WorkDate > '2008-04-01'
--where ProjectID = 182073 and TaskID = 6774934
order by rd.ProjectID, rd.TaskID, rd.ResourceNumber

--Aldea id 68299
select * 
from dbo.tblTask
where ProjectID = 52092 and TaskID = 686141

Update tblTask
Set Text14 = 68299
where ProjectID = 52092 and TaskID = 686141
*/
















