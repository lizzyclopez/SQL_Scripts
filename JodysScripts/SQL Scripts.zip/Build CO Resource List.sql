Use PIV_Reports 

select	 cor.ResourceNumber
		,cor.LastName
		,cor.FirstName
		,IsNull(cor.MI,'') as MI
		,cobc.Description as CO_BillingCode
		,pivbc.Description as PIV_BillingCode
		,cor.Onshore
		,cor.Offshore
		,IsNull(pivr.EDSJobCode,'') as EDSJobCode
from CO_Resource cor
join CO_BillingCode cobc
	on cor.Billing_CodeID = cobc.Billing_CodeID
join tblResource pivr
	on cor.ResourceNumber = pivr.ResourceNumber
join lkBillingCode pivbc
	on pivbc.Billing_CodeID = pivr.Billing_CodeID
Order by cor.LastName, cor.FirstName