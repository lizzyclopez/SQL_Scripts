Use PIV_Reports

drop table #TEMP_IN
drop table #TEMP_IN2
drop table #TEMP_OUT

-- =============================================
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @DateFrom datetime
	SET @DateFrom = '04/01/2008'

	DECLARE @DateTo datetime
	SET @DateTo = '04/30/2008'

	--DECLARE @CurrentMonth varchar(6)
	--SET @CurrentMonth = '200805'

	DECLARE @CODivisionList varchar(500)
	SET @CODivisionList = '-1'

	DECLARE @DeliveryLeadList varchar(500)
	SET @DeliveryLeadList = '-1'

	DECLARE @COStatusList varchar(500)
	SET @COStatusList = '-1'

	DECLARE @CORequestorList varchar(500)
	SET @CORequestorList = '-1'

	DECLARE @OutputTable varchar(30)
	SET @OutputTable = NULL

	Declare @AldeaProjectID varchar(100)
	Set @AldeaProjectID = 64412
	--Set @AldeaProjectID = Null

-- This is the start of the Stored Procedure
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Default the From and To Dates
	if ( @DateFrom is NULL )
		Set @DateFrom = '2000-01-01'
	if ( @DateTo is NULL )
		Set @DateTo = GetDate()

	-- Declare the needed common variables.
	Declare @SQL_statement varchar(1000), @row_count int, @Factor decimal(5,2)
	Declare @AldeaRequestNumber int
	Declare @OnShoreHours decimal(5,2)
	Declare @OffShoreHours decimal(5,2)
	Declare @RptDateFrom datetime
	Declare @RptDateTo datetime
	Declare @RptDateOnShoreHours decimal(5,2)
	Declare @RptDateOffShoreHours decimal(5,2)
	Declare @LastMonthPTDHours decimal(15,2)
	Declare @CurrentOnShorePTDHours decimal(15,2)
	Declare @CurrentOffShorePTDHours decimal(15,2)
	Declare @LastLockInDate datetime
	Declare @LastDayOfLastMonth datetime

	set @SQL_statement = ''

	-- Get the LastLockInDate
	Set @LastLockInDate = (Select FromDate From CO_PTD_LockInDate)

	-- Set the report date fields to the day after the last locking date through today.
	-- These dates will be used to sum the hours that have not been locked in yet for the
	-- purpose of calculating the PTD hours
	Set @RptDateFrom = @LastLockInDate + 1
	Set @RptDateTo = GetDate()

	-- Determine the last date of last month
	Set @LastDayOfLastMonth = Cast(Cast(Month(@DateFrom) as varchar (2)) + '/' + '01' + '/' +
							  Cast(Year(@DateFrom) as varchar (4)) as datetime) - 1

	-- Prepare the SQL WHERE clause for the new VIEW
	if ( @CODivisionList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and CODivision in ('+@CODivisionList+')'
	if ( @DeliveryLeadList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and EDSDeliveryLead in ('+@DeliveryLeadList+')'
	if ( @CORequestorList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and CORequestor in ('+@CORequestorList+')'
	if ( @COStatusList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and Status in ('+@COStatusList+')'
	if ( @AldeaProjectID Is Not Null )
	    select @SQL_statement = @SQL_statement+' and AldeaRequestNumber in ('+@AldeaProjectID+')'

	-- Drop the temp VIEW if it exists
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_Get_CO_Estimate_Tracking_Detail_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[SP_Get_CO_Estimate_Tracking_Detial_View]

	-- Build the new VIEW
	set @SQL_statement = 'Create View dbo.SP_Get_CO_Estimate_Tracking_Summary_View AS select * from CO_Estimate_Tracking_Summary_View where 1=1 ' + @SQL_statement

	--print '--- VIEW dbo.SP_Get_CO_Estimate_Tracking_Summary_View ---'
	--print @SQL_statement
	exec (@SQL_statement)

	select * into #TEMP_IN from dbo.SP_Get_CO_Estimate_Tracking_Summary_View
	exec('Drop View dbo.SP_Get_CO_Estimate_Tracking_Summary_View')

	-- Alter table definition
	ALTER TABLE #TEMP_IN ADD LastMonthPTDHours decimal(15,2) NULL
	ALTER TABLE #TEMP_IN ADD MonthlyActualHours decimal(15,2) NULL
	ALTER TABLE #TEMP_IN ADD OnshoreHours decimal(15,2) NULL
	ALTER TABLE #TEMP_IN ADD OffshoreHours decimal(15,2) NULL
	ALTER TABLE #TEMP_IN ADD CurrentPTDHours decimal(15,2) NULL
	ALTER TABLE #TEMP_IN ADD CurrentPTDOnshoreHours decimal(15,2) NULL
	ALTER TABLE #TEMP_IN ADD CurrentPTDoffshoreHours decimal(15,2) NULL

	-- Index the #TEMP_IN table
	--Create Index IDX1 on #TEMP_IN (CODivision, COSubDivision, AldeaRequestNumber)

	-- Build the where statement for the call to FTE_Approved_Time
	set @SQL_statement = ''

	-- Drop the second temp VIEW if it exists.
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_Get_CO_Estimate_Tracking_Summary_View2]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[SP_Get_CO_Estimate_Tracking_Summary_View2]

	-- Create the second temp VIEW
	set @SQL_statement = 'Create View dbo.SP_Get_CO_Estimate_Tracking_Summary_View2 AS select * from dbo.Aldea_Data a inner join CO_Actual_Hours_Worked h on a.RequestID = h.AldeaRequestId where Hours > 0 ' + @SQL_statement
	
	--print '--- VIEW dbo.SP_Get_CO_Estimate_Tracking_Summary_View2 ---'
	--print @SQL_statement
	exec (@SQL_statement)
	select * into #TEMP_IN2 from dbo.SP_Get_CO_Estimate_Tracking_Summary_View2

	-- Drop the second temp VIEW
	exec('Drop View dbo.SP_Get_CO_Estimate_Tracking_Summary_View2')

	-- Adjust the Hours according to the ProjectClientFundingPct by CO
	update #TEMP_IN2
	set Hours = isnull(ProjectClientFundingPct, 100) / 100 * Hours
	where isnull(ProjectClientFundingPct, 0) > 0

	-- Adjust the Hours according to the TaskClientFundingPct by CO
	update #TEMP_IN2
	set Hours = isnull(TaskClientFundingPct, 100) / 100 * Hours
	where isnull(TaskClientFundingPct, 0) > 0

	-- Populate each CODivision into the output table
	DECLARE AldeaRequest_cursor CURSOR FOR 
		select distinct AldeaRequestNumber from #TEMP_IN
		order by 	AldeaRequestNumber
	OPEN AldeaRequest_cursor
	FETCH NEXT FROM AldeaRequest_cursor INTO @AldeaRequestNumber
		WHILE @@FETCH_STATUS = 0
		BEGIN
			-- Sum up the Onshore Hours for each project based on the users select date
			Select	@OnShoreHours = Sum(IsNull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		Onshore = 1
			And		WorkDate >= @DateFrom
			And		WorkDate <= @DateTo

			-- Sum up the Offshore Hours for each project based on the users select date
			Select	@OffShoreHours = Sum(IsNull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		Offshore = 1
			And		WorkDate >= @DateFrom
			And		WorkDate <= @DateTo

			-- Sum up the Onshore Hours for each project based on the report date
			Select	@RptDateOnShoreHours = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		Onshore = 1
			And		WorkDate >= @RptDateFrom
			And		WorkDate <= @RptDateTo

			-- Sum up the Offshore Hours for each project based on the report date
			Select	@RptDateOffShoreHours = sum(isnull(Hours, 0))
			From	#TEMP_IN2
			Where	AldeaRequestId = @AldeaRequestNumber
			And		Offshore = 1
			And		WorkDate >= @RptDateFrom
			And		WorkDate <= @RptDateTo

			-- Reset LastMonthPTDHours
			Set @LastMonthPTDHours = 0

			-- Add the current total lockedin Onshore PDT hours up to the selected from date
			Set @LastMonthPTDHours = isnull(@LastMonthPTDHours, 0) +
				(Select	Sum(IsNull(OnshoreTotalHours, 0))
				 From	CO_PTD_Hours
				 Where	RequestID = @AldeaRequestNumber
				 And	SummaryDate <= @DateFrom
				)

			-- Add the current total lockedin Offshore PDT hours up to the selected from date
			Set @LastMonthPTDHours = isnull(@LastMonthPTDHours,0) +
				(Select	Sum(IsNull(OffshoreTotalHours, 0))
				 From	CO_PTD_Hours
				 Where	RequestID = @AldeaRequestNumber
				 And	SummaryDate <= @DateFrom
				)

			-- If the last lockin date is not up to date then include all hours from the last lockin
			-- through the last day of last month.
			If @LastLockInDate < @LastDayOfLastMonth
			Begin
				Set @LastMonthPTDHours = isnull(@LastMonthPTDHours,0) +
					(Select Sum(isnull(Hours, 0))
					 From	#TEMP_IN2
					 Where	AldeaRequestId = @AldeaRequestNumber
					 And	Onshore = 1
					 And	WorkDate > @LastLockInDate
					 And	WorkDate <= @LastDayOfLastMonth)

				Set @LastMonthPTDHours = isnull(@LastMonthPTDHours,0) +
					(Select Sum(isnull(Hours, 0))
					 From	#TEMP_IN2
					 Where	AldeaRequestId = @AldeaRequestNumber
					 And	Offshore = 1
					 And	WorkDate > @LastLockInDate
					 And	WorkDate <= @LastDayOfLastMonth)
			End

			-- Sum up the PTD Onshore Hours for each project							
			Select	@CurrentOnShorePTDHours = sum(isnull(OnshoreTotalHours, 0))
			From	CO_PTD_Hours
			Where	RequestID = @AldeaRequestNumber

			-- Include the report date hours in the PTD Hours
			Set @CurrentOnShorePTDHours = IsNull(@CurrentOnShorePTDHours,0) + IsNull(@RptDateOnShoreHours,0)

			-- Sum up the PTD Offshore Hours for each project
			Select	@CurrentOffShorePTDHours = sum(isnull(OffshoreTotalHours, 0))
			From	CO_PTD_Hours
			Where	RequestID = @AldeaRequestNumber

			-- Include the report date hours in the PTD Hours
			Set @CurrentOffShorePTDHours = IsNull(@CurrentOffShorePTDHours,0) + IsNull(@RptDateOffShoreHours,0)

			-- Update the temporary table for the current Onshore Hours
			Update	#TEMP_IN
			Set		LastMonthPTDHours = IsNull(@LastMonthPTDHours, 0),
					MonthlyActualHours = IsNull(@OnShoreHours, 0) + IsNull(@OffShoreHours, 0),
					OnshoreHours = IsNull(@OnShoreHours, 0),
					OffShoreHours = IsNull(@OffShoreHours, 0),
					CurrentPTDHours = IsNull(@CurrentOnShorePTDHours, 0) + IsNull(@CurrentOffShorePTDHours, 0),
					CurrentPTDOnshoreHours = IsNull(@CurrentOnShorePTDHours, 0),
					CurrentPTDOffshoreHours = IsNull(@CurrentOffShorePTDHours, 0)
			Where	AldeaRequestNumber = @AldeaRequestNumber

			FETCH NEXT FROM AldeaRequest_cursor INTO @AldeaRequestNumber
		END    
	CLOSE AldeaRequest_cursor
	DEALLOCATE AldeaRequest_cursor

	-- Create the output table #TEMP_OUT
	CREATE TABLE [dbo].[#TEMP_OUT] ( 
		[AutoKey][int] IDENTITY (0, 1) NOT NULL,
		[RecNumber][int] NULL,
		[RecType] [varchar] (255) NULL, -- CODivision / Program / SummaryDesc / Total / FTE Conversion
		[RecDesc] [varchar] (255) NULL,
		[RequestNumber] [varchar] (255) NULL,
		[AldeaRequestNumber] [int] Null,
		[RequestType] [varchar] (255) NULL,
		[CORequestor] [varchar] (255) NULL,
		[EDSDeliveryLead] [varchar] (255) NULL,
		[Tower] [varchar] (255) NULL,
		[Application] [varchar] (255) NULL,
		[Priority] [int] NULL,
		[Rank] [int] NULL,
		[ApprovedEstHours] [float] Null,
		[ApprovedEstHoursOnShore] [float] Null,
		[ApprovedEstHoursOffShore] [float] Null,
		[LastMonthPTDHours] [float] NULL,
		[MonthlyActualHours] [float] NULL,
		[OnshoreHours] [float] NULL,
		[OffshoreHours] [float] NULL,
		[CurrentPTDHours] [float] NULL,
		[CurrentPTDOnshoreHours] [float] NULL,
		[CurrentPTDOffshoreHours] [float] NULL,
		[Status] [varchar] (255) NULL,
		[DateReqeustReceived] [varchar] (2000) NULL,
		[DateReqeustAcknowledge] [varchar] (2000) Null,
		[DateEstimateSubmitted] [varchar] (2000) Null,
		[DateRequestCompleteAgreed] [varchar] (2000) Null,
		[DateRequestActualComplete] [varchar] (2000) Null,
		[R10_CODivision] [varchar] (255) NULL,
		[R20_COSubDivision] [varchar] (255) NULL,
		[R30_COProject] [varchar] (255) NULL,
		[R40_COTask] [varchar] (255) NULL,
		[R50_COResource] [varchar] (255) NULL
	) ON [PRIMARY]

	-- Check to see if we have data to process
	select @row_count = count(*) from #TEMP_IN
	if @row_count = 0
	begin
		insert #TEMP_OUT (RecNumber) values (99)
		goto No_Data_To_Process
	end

	---------------------------------------------------------------------------------------------------
	-- Declare additional needed fields.
	DECLARE @CurCODivision varchar(255), @MaxDivisionGroup int,
			@CurCOSubDivision varchar(255), @MaxCOSubDivision int, 
			@CurSummaryDesc varchar (255), @MaxSummaryDesc int,
			@CurAldeaRequestNumber int,
			@CurProjectID varchar(100), @MaxProj bigint, @CurProjectTitle varchar(100),
			@CurTaskID varchar(100), @MaxTask bigint, @CurTaskName varchar(100),
			@CurResourceNumber varchar(100), @MaxResource bigint, 
			@CurResourceFName varchar(100), @CurResourceLName varchar(100), @CurResourceMI varchar(2),
			@SummTotalOnshoreHours decimal(15,2), @SummTotalOffshoreHours decimal(15,2),
			@ProjTotalOnshoreHours decimal(15,2), @ProjTotalOffshoreHours decimal(15,2),
			@TaskTotalOnshoreHours decimal(15,2), @TaskTotalOffshoreHours decimal(15,2)
	DECLARE @ApprovedEstHours float, @ApprovedEstHoursOnShore float, @ApprovedEstHoursOffShore float
	DECLARE @DateReqeustReceived varchar(50), @DateReqeustAcknowledge varchar(50), @DateEstimateSubmitted varchar(50)
	DECLARE @DateRequestCompleteAgreed varchar(50), @DateRequestActualComplete varchar(50)

	Set @SummTotalOnshoreHours = 0
	Set @SummTotalOffshoreHours = 0
	Set @ProjTotalOnshoreHours = 0
	Set @ProjTotalOffshoreHours = 0
	Set @TaskTotalOnshoreHours = 0
	Set @TaskTotalOffshoreHours = 0

	---------------------------------------------------------------------------------------------------
	-- Populate each CODivision into the output table
	DECLARE CODivision_cursor CURSOR FOR 
		select distinct CODivision from #TEMP_IN
		where CODivision is not null
		order by 	CODivision
	OPEN CODivision_cursor
	FETCH NEXT FROM CODivision_cursor INTO @CurCODivision
		WHILE @@FETCH_STATUS = 0
		BEGIN
			insert #TEMP_OUT (RecNumber) values (10) -- A blank line
			insert #TEMP_OUT (RecNumber, RecType, RecDesc)
 			select 10, 'CODivision', @CurCODivision
			select @MaxDivisionGroup = max(AutoKey) from #TEMP_OUT

	---------------------------------------------------------------------------------------------------
			-- Populate each COSubDivision into the output table
			DECLARE COSubDivision_cursor CURSOR FOR 
				select distinct COSubDivision from #TEMP_IN
				where CODivision = @CurCODivision and COSubDivision is not null
				order by COSubDivision
	            
			OPEN COSubDivision_cursor
			FETCH NEXT FROM COSubDivision_cursor INTO @CurCOSubDivision
        		WHILE @@FETCH_STATUS = 0
				BEGIN
        			insert #TEMP_OUT (RecNumber, RecType, RecDesc, R10_CODivision)
					select 20, 'COSubDivision', @CurCOSubDivision, @CurCODivision
					select @MaxCOSubDivision = max(AutoKey) from #TEMP_OUT

	---------------------------------------------------------------------------------------------------                
					-- Populate each Summary Desc into the output table.
					DECLARE SummaryDesc_cursor CURSOR FOR 
						select distinct RequestSummary, AldeaRequestNumber from #TEMP_IN
						where CODivision = @CurCODivision and COSubDivision = @CurCOSubDivision and AldeaRequestNumber is not null
						order by RequestSummary

					OPEN SummaryDesc_cursor
					FETCH NEXT FROM SummaryDesc_cursor INTO @CurSummaryDesc, @CurAldeaRequestNumber
						WHILE @@FETCH_STATUS = 0
    					BEGIN
    						insert #TEMP_OUT (RecNumber, RecType, RecDesc, AldeaRequestNumber ,R10_CODivision, R20_COSubDivision)
       		   				select 30, 'SummaryDesc', @CurSummaryDesc, @CurAldeaRequestNumber, @CurCODivision, @CurCOSubDivision
							select @MaxSummaryDesc = max(AutoKey) from #TEMP_OUT
							Select @ApprovedEstHours = (select IsNull(ApprovedEstHours,0) from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							Select @ApprovedEstHoursOffShore = (select IsNull(ApprovedEstHoursOffShore,0) from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							Set @ApprovedEstHoursOnShore = IsNull(@ApprovedEstHours,0) - IsNull(@ApprovedEstHoursOffShore,0)							-- Changed the date formats for display.							Select @DateReqeustReceived = (select DateReqeustReceived from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							If (IsDate(@DateReqeustReceived) = 1)							Begin								Set @DateReqeustReceived =	Right('00' + Cast(Month(@DateReqeustReceived) as VarChar(2)),2) + '/' +															Right('00' + Cast(Day(@DateReqeustReceived) as VarChar(2)),2) + '/' +															Cast(Year(@DateReqeustReceived) as char(4))							End							Select @DateReqeustAcknowledge = (select DateReqeustAcknowledge from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							If (IsDate(@DateReqeustAcknowledge) = 1)							Begin								Set @DateReqeustAcknowledge =	Right('00' + Cast(Month(@DateReqeustAcknowledge) as VarChar(2)),2) + '/' +																Right('00' + Cast(Day(@DateReqeustAcknowledge) as VarChar(2)),2) + '/' +																Cast(Year(@DateReqeustAcknowledge) as char(4))							End							Select @DateEstimateSubmitted = (select DateEstimateSubmitted from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							If (IsDate(@DateEstimateSubmitted) = 1)							Begin								Set @DateEstimateSubmitted =	Right('00' + Cast(Month(@DateEstimateSubmitted) as VarChar(2)),2) + '/' +																Right('00' + Cast(Day(@DateEstimateSubmitted) as VarChar(2)),2) + '/' +																Cast(Year(@DateEstimateSubmitted) as char(4))							End							Select @DateRequestCompleteAgreed = (select DateRequestCompleteAgreed from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							If (IsDate(@DateRequestCompleteAgreed) = 1)							Begin								Set @DateRequestCompleteAgreed =	Right('00' + Cast(Month(@DateRequestCompleteAgreed) as VarChar(2)),2) + '/' +																Right('00' + Cast(Day(@DateRequestCompleteAgreed) as VarChar(2)),2) + '/' +																Cast(Year(@DateRequestCompleteAgreed) as char(4))							End							Select @DateRequestActualComplete = (select DateRequestActualComplete from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber)							If (IsDate(@DateRequestActualComplete) = 1)							Begin								Set @DateRequestActualComplete =	Right('00' + Cast(Month(@DateRequestActualComplete) as VarChar(2)),2) + '/' +																Right('00' + Cast(Day(@DateRequestActualComplete) as VarChar(2)),2) + '/' +																Cast(Year(@DateRequestActualComplete) as char(4))							End							-- Update the TEMP_OUT table							update #TEMP_OUT
							set RequestNumber 		= (select RequestNumber from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								RequestType 		= (select RequestType from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								CORequestor	 		= (select CORequestor from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								EDSDeliveryLead		= (select EDSDeliveryLead from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								Tower				= (select Tower from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								[Application] 		= (select [Application] from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								Priority 			= (select Priority from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								Rank	 			= (select Rank from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								ApprovedEstHours 			= IsNull(@ApprovedEstHours,0),
								ApprovedEstHoursOnShore		= IsNull(@ApprovedEstHoursOnShore,0),
								ApprovedEstHoursOffShore	= IsNull(@ApprovedEstHoursOffShore,0),								
								LastMonthPTDHours	= (select LastMonthPTDHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								MonthlyActualHours	= (select MonthlyActualHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								OnshoreHours		= (select OnshoreHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								OffshoreHours       = (select OffshoreHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								CurrentPTDHours     = (select CurrentPTDHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								CurrentPTDOnshoreHours	= (select CurrentPTDOnshoreHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								CurrentPTDOffshoreHours = (select CurrentPTDOffshoreHours from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								Status 					= (select Status from #TEMP_IN where AldeaRequestNumber = @CurAldeaRequestNumber),
								DateReqeustReceived 	= @DateReqeustReceived,
								DateReqeustAcknowledge 	= @DateReqeustAcknowledge,
								DateEstimateSubmitted 	= @DateEstimateSubmitted,
								DateRequestCompleteAgreed 	= @DateRequestCompleteAgreed,
								DateRequestActualComplete 	= @DateRequestActualComplete							where AutoKey = @MaxSummaryDesc	---------------------------------------------------------------------------------------------------                
							-- Populate each Project Title into the output table.
							DECLARE Project_cursor CURSOR FOR 
								select distinct ProjectID, ProjectTitle from #TEMP_IN2
								where AldeaRequestID = @CurAldeaRequestNumber
								and	WorkDate >= @DateFrom
								and	WorkDate <= @DateTo

							OPEN Project_cursor
							FETCH NEXT FROM Project_cursor INTO @CurProjectID, @CurProjectTitle
								WHILE @@FETCH_STATUS = 0
    							BEGIN
    								insert #TEMP_OUT (RecNumber, RecType, RecDesc, R10_CODivision, R20_COSubDivision, R30_COProject)
       		   						select 40, 'ProjectDesc', @CurProjectTitle, @CurCODivision, @CurCOSubDivision, @CurProjectID
									select @MaxProj = max(AutoKey) from #TEMP_OUT
	---------------------------------------------------------------------------------------------------                
									-- Populate each Task Name into the output table.
									DECLARE Task_cursor CURSOR FOR 
										select distinct TaskId, TaskName from #TEMP_IN2
										where AldeaRequestID = @CurAldeaRequestNumber
										and ProjectId = @CurProjectID
										and	WorkDate >= @DateFrom
										and	WorkDate <= @DateTo

									OPEN Task_cursor
									FETCH NEXT FROM Task_cursor INTO @CurTaskID, @CurTaskName
										WHILE @@FETCH_STATUS = 0
										BEGIN
											insert #TEMP_OUT (RecNumber, RecType, RecDesc, R10_CODivision, R20_COSubDivision, R30_COProject, R40_COTask)
   		   									select 50, 'TaskDesc', @CurTaskName, @CurCODivision, @CurCOSubDivision, @CurProjectID, @CurTaskID
											select @MaxTask = max(AutoKey) from #TEMP_OUT
	---------------------------------------------------------------------------------------------------                
											-- Populate each Resource into the output table.
											DECLARE Resource_cursor CURSOR FOR 
												select distinct ResourceNumber, LastName, FirstName, MI from #TEMP_IN2
												where AldeaRequestID = @CurAldeaRequestNumber
												and ProjectId = @CurProjectID
												and TaskID = @CurTaskID
												and	WorkDate >= @DateFrom
												and	WorkDate <= @DateTo

											OPEN Resource_cursor
											FETCH NEXT FROM Resource_cursor INTO @CurResourceNumber, @CurResourceLName, @CurResourceFName, @CurResourceMI
												WHILE @@FETCH_STATUS = 0
												BEGIN
													insert #TEMP_OUT (RecNumber, RecType, RecDesc, R10_CODivision, R20_COSubDivision, R30_COProject, R40_COTask, R50_COResource)
   		   											select 60, 'ResourceDesc', @CurResourceLName + ', ' + @CurResourceFName + ' ' + IsNull(@CurResourceMI,''), 
																@CurCODivision, @CurCOSubDivision, @CurProjectID, @CurTaskID, @CurResourceLName + ', ' + @CurResourceFName + ' ' + IsNull(@CurResourceMI,'')
													select @MaxResource = Max(AutoKey) from #TEMP_OUT
													
													-- Sum up the Onshore Hours for each Resource
													Select	@OnShoreHours = Sum(IsNull(Hours, 0))
													From	#TEMP_IN2
													Where	ResourceNumber = @CurResourceNumber
													And		TaskID = @CurTaskID
													And		ProjectID = @CurProjectID
													And		AldeaRequestID = @CurAldeaRequestNumber
													And		Onshore = 1
													And		WorkDate >= @DateFrom
													And		WorkDate <= @DateTo

													-- Sum up the Offshore Hours for each Resource
													Select	@OffShoreHours = Sum(Isnull(Hours, 0))
													From	#TEMP_IN2
													Where	ResourceNumber = @CurResourceNumber
													And		TaskID = @CurTaskID
													And		ProjectID = @CurProjectID
													And		AldeaRequestID = @CurAldeaRequestNumber
													And		Offshore = 1
													And		WorkDate >= @DateFrom
													And		WorkDate <= @DateTo

													Update	#TEMP_OUT
													Set		OnshoreHours = Isnull(@OnShoreHours,0),
															OffShoreHours = Isnull(@OffShoreHours,0)
													where	AutoKey = @MaxResource

													Set @TaskTotalOnshoreHours = IsNull(@TaskTotalOnshoreHours,0) + Isnull(@OnShoreHours,0)
													Set @TaskTotalOffshoreHours = IsNull(@TaskTotalOffshoreHours,0) + Isnull(@OffShoreHours,0)

													FETCH NEXT FROM Resource_cursor INTO @CurResourceNumber, @CurResourceLName, @CurResourceFName, @CurResourceMI
												End
											CLOSE Resource_cursor
											DEALLOCATE Resource_cursor
	--------------------------------------------------------------------------------------------------
											Update	#TEMP_OUT
											Set		OnshoreHours = IsNull(@TaskTotalOnshoreHours, 0),
													OffShoreHours = IsNull(@TaskTotalOffshoreHours, 0)
											Where   RecType = 'TaskDesc'
											And		R40_CoTask = @CurTaskID

											Set @ProjTotalOnshoreHours = IsNull(@ProjTotalOnshoreHours,0) + IsNull(@TaskTotalOnshoreHours, 0)
											Set @TaskTotalOnshoreHours = 0

											Set @ProjTotalOffshoreHours = IsNull(@ProjTotalOffshoreHours,0) + IsNull(@TaskTotalOffshoreHours, 0)
											Set @TaskTotalOffshoreHours = 0

											FETCH NEXT FROM Task_cursor INTO @CurTaskID, @CurTaskName
										End
									CLOSE Task_cursor
									DEALLOCATE Task_cursor
	--------------------------------------------------------------------------------------------------
									Update	#TEMP_OUT
									Set		OnshoreHours = IsNull(@ProjTotalOnshoreHours, 0),
											OffShoreHours = IsNull(@ProjTotalOffshoreHours, 0)
									Where   RecType = 'ProjectDesc'
									And		R30_CoProject = @CurProjectID

									Set @SummTotalOnshoreHours = IsNull(@SummTotalOnshoreHours,0) + IsNull(@ProjTotalOnshoreHours, 0)
									Set @ProjTotalOnshoreHours = 0

									Set @SummTotalOffshoreHours = IsNull(@SummTotalOffshoreHours,0) + IsNull(@ProjTotalOffshoreHours, 0)
									Set @ProjTotalOffshoreHours = 0

									FETCH NEXT FROM Project_cursor INTO @CurProjectID, @CurProjectTitle
								End
							CLOSE Project_cursor
							DEALLOCATE Project_cursor
	--------------------------------------------------------------------------------------------------
/*
							Update	#TEMP_OUT
							Set		MonthlyActualHours = IsNull(@SummTotalOnshoreHours, 0) + IsNull(@SummTotalOffshoreHours, 0),
									OnshoreHours = IsNull(@SummTotalOnshoreHours, 0),
									OffShoreHours = IsNull(@SummTotalOffshoreHours, 0)
							Where   RecType = 'SummaryDesc'
							And		R20_CoSubDivision = @CurCOSubDivision
*/
							Set @SummTotalOnshoreHours = 0
							Set @SummTotalOffshoreHours = 0

							FETCH NEXT FROM SummaryDesc_cursor INTO @CurSummaryDesc, @CurAldeaRequestNumber
						END    
					CLOSE SummaryDesc_cursor
					DEALLOCATE SummaryDesc_cursor
	--------------------------------------------------------------------------------------------------
					FETCH NEXT FROM COSubDivision_cursor INTO @CurCOSubDivision
				END
			CLOSE COSubDivision_cursor
			DEALLOCATE COSubDivision_cursor
	---------------------------------------------------------------------------------------------------
			FETCH NEXT FROM CODivision_cursor INTO @CurCODivision
		END
	CLOSE CODivision_cursor
	DEALLOCATE CODivision_cursor
	---------------------------------------------------------------------------------------------------
	No_Data_To_Process:
	SET NOCOUNT OFF

	-- Output the result
	If ( @OutputTable is NULL )
		Select RecNumber, RecType, RecDesc, 
				Case Len(RTrim(RequestNumber))
					When 0	Then Null
				Else RequestNumber
				End As RequestNumber,
				AldeaRequestNumber, RequestType, CORequestor, EDSDeliveryLead, Tower, [Application], Priority, 
				Rank, ApprovedEstHours, ApprovedEstHoursOnShore, ApprovedEstHoursOffShore, LastMonthPTDHours,
				MonthlyActualHours, OnshoreHours, OffshoreHours, CurrentPTDHours, CurrentPTDOnshoreHours,
				CurrentPTDOffshoreHours, Status, DateReqeustReceived, DateReqeustAcknowledge, DateEstimateSubmitted,
				DateRequestCompleteAgreed, DateRequestActualComplete, 
				R10_CODivision, R20_COSubDivision, R30_COProject, R40_COTask, R50_COResource
		From #TEMP_OUT
		Order By AutoKey
	Else 
	Begin
		-- order by AutoKey will be included in the calling
		Set @SQL_statement = 'Select * into '+@OutputTable+' from #TEMP_OUT'
		Exec (@SQL_statement)
	End