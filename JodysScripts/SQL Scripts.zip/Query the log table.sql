Use PIV_Import

select top 100 *
from log
where ts > '06/09/2008'
and text Like '%Aldea%'
order by ts desc


Use Aldea_Import
select * 
from AldeaDataView
where REQUEST_ID = 67744


use PIV_Reports
select *
from Aldea_Data
where RequestID = 67744