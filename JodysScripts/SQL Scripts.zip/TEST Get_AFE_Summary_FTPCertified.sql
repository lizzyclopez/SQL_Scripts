Use PIV_Reports

drop table #TEMP_IN
drop table #TEMP_OUT

Declare @DateFrom datetime
Declare @DateTo datetime
Declare @CurrentMonth varchar(6)
Declare @ProgGroupID varchar(100)
Declare @FundCatIDList varchar(100)
Declare @ITSABillingCat varchar(30)
Declare @SolutionCentreList varchar(500)
Declare @BillingShoreWhere varchar(20)
Declare @OutputTable varchar(30)

Set @DateFrom = '05/01/2008'
Set @DateTo = '05/31/2008'
Set @CurrentMonth = '200805'
Set @ProgGroupID = '-1'
Set @FundCatIDList = '-1'
Set @ITSABillingCat = '-1'
--Set @SolutionCentreList = '''HOUSTON SOLUTION CENTRE'',''MIRAMAR SOLUTION CENTRE'''
Set @SolutionCentreList = Null
--Set @BillingShoreWhere = NULL					-- 
--Set @BillingShoreWhere = ' and Offshore=1'	-- 
Set @BillingShoreWhere = ' and Onshore=1'		-- 
Set @OutputTable = NULL

	-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
	SET NOCOUNT ON;

	--Default the From and To Dates.
	if ( @DateFrom is NULL )
		Set @DateFrom = '2000-01-01'
	if ( @DateTo is NULL )
		Set @DateTo = GetDate()

	-- Declare common variables.
	Declare @SQL_statement varchar(1000)
	set @SQL_statement = ''

	--Passed in from the web for @FundCatIDList.
	--The DLL converts '3005' to  '3003,3004'
	--<option value="3005">AFE-All</option>
	--<option value="3003">AFE-Non Shr</option>
	--<option value="3004">AFE-SHR </option>
	--<option value="3001">Other/Miscellaneous</option>
	--<option value="3002">Special Projects</option>
	--<option value="3000">Support</option>

	-- Build the WHERE clause for the new VIEW.
	if ( @DateFrom is not NULL )
	    select @SQL_statement = @SQL_statement+' and WorkDate >= '''+convert(varchar(25), @DateFrom, 101)+''''
	if ( @DateTo is not NULL )
	    select @SQL_statement = @SQL_statement+' and WorkDate <= '''+convert(varchar(25), @DateTo, 101)+''''
	if ( @ProgGroupID <> '-1' )
	    select @SQL_statement = @SQL_statement+' and Prog_GroupID in ('+@ProgGroupID+')'
	--if ( @FundCatID > 0 )
	--    select @SQL_statement = @SQL_statement+' and Funding_CatID = '+convert(varchar(10), @FundCatID)
	if ( @FundCatIDList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and Funding_CatID in ('+@FundCatIDList+')'
	if ( @SolutionCentreList <> '-1' )
		--select @SQL_statement = @SQL_statement+' and 1=2' -- Exclude All Custome Data
		select @SQL_statement = @SQL_statement+' and ResourceOrg in ('+@SolutionCentreList+')'
	if ( @ITSABillingCat <> '-1' )
	    select @SQL_statement = @SQL_statement+' and ITSABillingCat in ('+@ITSABillingCat+')'
	if ( @BillingShoreWhere is not NULL )
	    select @SQL_statement = @SQL_statement + @BillingShoreWhere

	-- Drop the temp VIEW if it exists.
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_Get_AFE_Summary_FTP_View]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[SP_Get_AFE_Summary_FTP_View]

	-- Create new temp VIEW.
	set @SQL_statement = 'Create View dbo.SP_Get_AFE_Summary_FTP_View AS select AFE_Summary_View.*, CO_Resource.Onshore, CO_Resource.Offshore, 
		CO_Resource.Hourly, CO_BillingCode.Billing_CodeID, CO_BillingCode.Description AS NewBillingType
		from AFE_Summary_View inner join CO_Resource ON AFE_Summary_View.EDSNETID = CO_Resource.ResourceNumber
		inner join CO_BillingCode ON CO_BillingCode.Billing_CodeID = CO_Resource.Billing_CodeID
		where 1=1 ' + @SQL_statement
		--where 1=1 and WorkDate >= ''04/01/2008'' and WorkDate <= ''04/30/2008'' '
	exec (@SQL_statement) 

	-- Copy the data from the temp VIEW into #TEMP_IN working storage.
	select * into #TEMP_IN from dbo.SP_Get_AFE_Summary_FTP_View
	
	-- Drop the temp VIEW.
	exec('Drop View dbo.SP_Get_AFE_Summary_FTP_View')

	-- Alter table definitions.
	ALTER TABLE #TEMP_IN ADD Appr_FTE_Hours decimal(7,2) NULL
	ALTER TABLE #TEMP_IN ADD CurrentMonth varchar(6) NULL
	ALTER TABLE #TEMP_IN ALTER COLUMN TaskID int NULL
	ALTER TABLE #TEMP_IN ALTER COLUMN ProjectID bigint NULL
	ALTER TABLE #TEMP_IN ALTER COLUMN WorkDate datetime NULL
	ALTER TABLE #TEMP_IN ALTER COLUMN EDSNETID varchar(15) NULL
	ALTER TABLE #TEMP_IN ALTER COLUMN Billing_CodeID int NULL
	ALTER TABLE #TEMP_IN ALTER COLUMN NewBillingType varchar(50) NULL

	-- Drop the second temp VIEW if it exists.
	if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SP_Get_AFE_Summary_FTP_View2]') and OBJECTPROPERTY(id, N'IsView') = 1)
	drop view [dbo].[SP_Get_AFE_Summary_FTP_View2]

	-- Build the where statement for View2.
	set @SQL_statement = ''
	if ( @CurrentMonth is not NULL )
		select @SQL_statement = @SQL_statement+' and CurrentMonth = '+@CurrentMonth
	if ( @ProgGroupID <> '-1' )
	    select @SQL_statement = @SQL_statement+' and Prog_GroupID in ('+@ProgGroupID+')'
	--if ( @FundCatID > 0 )
	--    select @SQL_statement = @SQL_statement+' and Funding_CatID = '+convert(varchar(10), @FundCatID)
	if ( @FundCatIDList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and Funding_CatID in ('+@FundCatIDList+')'
	if ( @SolutionCentreList <> '-1' )
	    select @SQL_statement = @SQL_statement+' and 1=2' -- Exclude All Customer Data
	
	-- Create the second temp VIEW.
	--Jody Ennen - Added two joins in order to get the ITSABillingCat
	--set @SQL_statement = 'Create View dbo.SP_Get_AFE_Summary_FTP_View2 AS select * from FTE_Approved_Time where Appr_FTE_Hours > 0 ' + @SQL_statement
	set @SQL_statement = 'Create View dbo.SP_Get_AFE_Summary_FTP_View2 AS select dbo.lkITSABillingCategory.Description AS ITSABillingCat, 
			FTE_Approved_Time.* from FTE_Approved_Time LEFT OUTER JOIN	dbo.tblAFEDetail 
			ON FTE_Approved_Time.AFE_DescID = dbo.tblAFEDetail.AFE_DescID 
			LEFT OUTER JOIN dbo.lkITSABillingCategory 
			ON dbo.tblAFEDetail.ITSABillingCategoryID = dbolkITSABillingCategory.ITSABillingCategoryID 
			where Appr_FTE_Hours > 0' + @SQL_statement

	exec (@SQL_statement)

	-- Copy the data from the second temp VIEW into #TEMP_IN.
	insert #TEMP_IN (AFEDesc, Program, ProgramGroup, Prog_GroupID, ProgramID, Appr_FTE_Hours, CurrentMonth, AFE_DescID, Funding_CatID, COBusinessLead, ITSABillingCat )
	select AFEDesc, Program, ProgramGroup, Prog_GroupID, ProgramID, Appr_FTE_Hours, CurrentMonth, AFE_DescID, Funding_CatID, COBusinessLead, ITSABillingCat from dbo.SP_Get_AFE_Summary_FTP_View2
	
	-- Drop the second temp VIEW.
	exec('Drop View dbo.SP_Get_AFE_Summary_FTP_View2')
	
	-- Index the #TEMP_IN table.
	Create Index IDX1 on #TEMP_IN (Prog_GroupID, ProgramID, AFE_DescID, NewBillingType)

	-- Adjust the Hours according to the ClientFundingPct by CO.
	update #TEMP_IN set Hours = isnull(ClientFundingPct,100)/100*Hours where isnull( ClientFundingPct,0) > 0
	update #TEMP_IN set Hours = isnull(TaskClientFundingPct,100)/100*Hours where isnull(TaskClientFundingPct,0) > 0

	-- Set the Factor.
	--declare @Factor decimal(5,2)
	--if (month(@datefrom) <> month(getdate())) or ( year(@datefrom) <> year(getdate()))
	--    set @Factor = 1
	--else
	--    select @Factor = convert(float, day(getdate())) / convert(float, day(DATEADD(d, -DAY(DATEADD(m,1,getdate())),DATEADD(m,1,getdate()))))

	-- Create the output table #TEMP_OUT.
	CREATE TABLE [dbo].[#TEMP_OUT] ( 
		[AutoKey][int] IDENTITY (0, 1) NOT NULL,
		[RecNumber][int] NULL,
		[RecType] [varchar] (100) NULL, -- ProgramGroup Totals / Program / AFEDesc / Total / FTE Conversion
		[RecDesc] [varchar] (100) NULL,
		[RecTypeID] [bigint] NULL,
		[ITSABillingCat] [varchar] (30) NULL,
		[FundingCat] [varchar] (30) NULL,
		[AFENumber] [varchar] (20) NULL,
		[COBusinessLead] [varchar] (100) NULL,
		[ProgramMgr] [varchar] (50) NULL,
		[Location] [varchar] (30) NULL,
		[TotalHours] [decimal](10,2) NULL,
		[ActualFTEs] [decimal](10,2) NULL,
		[COApprovedFTEs] [decimal](10,2) NULL,
		[EDSVariance] [decimal](10,2) NULL,
		[MCSDOnshoreHours] [decimal](10,2) NULL,
		[MCSDOffshoreHours] [decimal](10,2) NULL,
		[MCSDHourlyHours] [decimal](10,2) NULL,
		[MCADOnshoreHours] [decimal](10,2) NULL,
		[MCADOffshoreHours] [decimal](10,2) NULL,
		[MCADHourlyHours] [decimal](10,2) NULL,
		[MSDBAOnshoreHours] [decimal](10,2) NULL,
		[MSDBAOffshoreHours] [decimal](10,2) NULL,
		[MSDBAHourlyHours] [decimal](10,2) NULL,
		[SCJPOnshoreHours] [decimal](10,2) NULL,
		[SCJPOffshoreHours] [decimal](10,2) NULL,
		[SCJPHourlyHours] [decimal](10,2) NULL,
		[SCJDOnshoreHours] [decimal](10,2) NULL,
		[SCJDOffshoreHours] [decimal](10,2) NULL,
		[SCJDHourlyHours] [decimal](10,2) NULL,
		[SCEAOnshoreHours] [decimal](10,2) NULL,
		[SCEAOffshoreHours] [decimal](10,2) NULL,
		[SCEAHourlyHours] [decimal](10,2) NULL,
		[OCP9IOnshoreHours] [decimal](10,2) NULL,
		[OCP9IOffshoreHours] [decimal](10,2) NULL,
		[OCP9IHourlyHours] [decimal](10,2) NULL,
		[OCP10IOnshoreHours] [decimal](10,2) NULL,
		[OCP10IOffshoreHours] [decimal](10,2) NULL,
		[OCP10IHourlyHours] [decimal](10,2) NULL,
		[SQLOnshoreHours] [decimal](10,2) NULL,
		[SQLOffshoreHours] [decimal](10,2) NULL,
		[SQLHourlyHours] [decimal](10,2) NULL,
		--[ExpectedMTDFTE] [decimal](10,2) NULL,
		--[VarianceMTDFTE] [decimal](10,2) NULL,
		[R10_ProgramGroup] [varchar] (100) NULL,
		[R20_Program] [varchar] (100) NULL
	) ON [PRIMARY]

	-- Check to see if we have data to process.
	declare @row_count int
	select @row_count = count(*) from #TEMP_IN
	if @row_count = 0
	begin
		insert #TEMP_OUT (RecNumber) values (99)
		goto No_Data_To_Process	
	end

	-- Data was found, build the report.	
	---------------------------------------------------------------------------------------------------
	-- Declare additional variables.
	DECLARE @CurProgramGroup varchar(100), @CurProg_GroupID int, @CurProgram varchar(100), @CurProgramID int, @CurCOBusinessLead varchar(100), @CurAFEDesc varchar(100), @CurAFE_DescID int, @MaxProgGroup int, @MaxProgram int, @MaxAFEDesc int, @MaxProj bigint
	--@ITSABillingCat varchar(30), 

	-- Populate summary rows.
	insert #TEMP_OUT (RecNumber, RecType, RecDesc)
	select 0, 'GrandTotal', 'Total FTP Certified'
	insert #TEMP_OUT (RecNumber, RecType, RecDesc)
	select 3, 'Conversion', 'FTE Conversion'

	-- ProgramGroup_cursor populates at the Program Group level, record type 10.
	DECLARE ProgramGroup_cursor CURSOR FOR 
		select distinct ProgramGroup, Prog_GroupID from #TEMP_IN 
		where ProgramGroup is not null order by ProgramGroup
	OPEN ProgramGroup_cursor
	FETCH NEXT FROM ProgramGroup_cursor INTO @CurProgramGroup, @CurProg_GroupID
		WHILE @@FETCH_STATUS = 0
		BEGIN
			insert #TEMP_OUT (RecNumber) values (10) -- A blank line
			insert #TEMP_OUT (RecNumber, RecType, RecDesc, RecTypeID) 
			select 10, 'ProgGroup/Total', @CurProgramGroup, @CurProg_GroupID
			select @MaxProgGroup = max(AutoKey) from #TEMP_OUT 

			---------------------------------------------------------------------------------------------------
	
			-- Program_cursor populates at the Program level, record type 20.
			DECLARE Program_cursor CURSOR FOR 
				select distinct Program, ProgramID, COBusinessLead from #TEMP_IN
				where ProgramGroup = @CurProgramGroup and Program is not null order by Program				
			OPEN Program_cursor
			FETCH NEXT FROM Program_cursor INTO @CurProgram, @CurProgramID, @CurCOBusinessLead
				WHILE @@FETCH_STATUS = 0
				BEGIN
					--insert #TEMP_OUT (RecNumber, RecType, RecDesc, RecTypeID, COBusinessLead) 
					--select 20, 'Program', @CurProgram, @CurProgramID, @CurCOBusinessLead
	        		insert #TEMP_OUT (RecNumber, RecType, RecDesc, RecTypeID, R10_ProgramGroup, COBusinessLead)
		            select 20, 'Program', @CurProgram, @CurProgramID, @CurProgramGroup, @CurCOBusinessLead
					select @MaxProgram = max(AutoKey) from #TEMP_OUT 
	
					----------------------------------------------------------------------------------------------
	
					-- AFEDesc_cursor populates at the AFE level, record type 30.
					DECLARE AFEDesc_cursor CURSOR FOR 
						select distinct AFEDesc, AFE_DescID from #TEMP_IN 
						where ProgramGroup = @CurProgramGroup and Program = @CurProgram and AFEDesc is not null order by AFEDesc
					OPEN AFEDesc_cursor
					FETCH NEXT FROM AFEDesc_cursor INTO @CurAFEDesc, @CurAFE_DescID
						WHILE @@FETCH_STATUS = 0
        				BEGIN
        					--insert #TEMP_OUT (RecNumber, RecType, RecDesc, RecTypeID) 
							--select 30, 'AFEDesc', @CurAFEDesc, @CurAFE_DescID
        					insert #TEMP_OUT (RecNumber, RecType, RecDesc, RecTypeID, R10_ProgramGroup, R20_Program)
           		   			select 30, 'AFEDesc', @CurAFEDesc, @CurAFE_DescID, @CurProgramGroup, @CurProgram
							select @MaxAFEDesc = max(AutoKey) from #TEMP_OUT

							--------------------------------------------------------------------------------------------
					
							-- Populate the ITSA Billing Category.
							select @ITSABillingCat = ITSABillingCat from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID 

							-- Populate the Hours by the new Billing Type.
							declare @MCSDOnshore decimal(10,2), @MCSDOffshore decimal(10,2), @MCSDHourly decimal(10,2), 
								@MCADOnshore decimal(10,2), @MCADOffshore decimal(10,2), @MCADHourly decimal(10,2),
								@MSDBAOnshore decimal(10,2), @MSDBAOffshore decimal(10,2), @MSDBAHourly decimal(10,2),
								@SCJPOnshore decimal(10,2), @SCJPOffshore decimal(10,2), @SCJPHourly decimal(10,2),
								@SCJDOnshore decimal(10,2), @SCJDOffshore decimal(10,2), @SCJDHourly decimal(10,2),
								@SCEAOnshore decimal(10,2), @SCEAOffshore decimal(10,2), @SCEAHourly decimal(10,2),
								@OCP9IOnshore decimal(10,2), @OCP9IOffshore decimal(10,2), @OCP9IHourly decimal(10,2),
								@OCP10IOnshore decimal(10,2), @OCP10IOffshore decimal(10,2), @OCP10IHourly decimal(10,2),
								@SQLOnshore decimal(10,2), @SQLOffshore decimal(10,2), @SQLHourly decimal(10,2)
       
							select @MCSDOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MCSD' and Onshore = 1
							select @MCSDOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MCSD' and Offshore = 1
							select @MCSDHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MCSD' and Hourly = 1

							select @MCADOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MCAD' and Onshore = 1
							select @MCADOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MCAD' and Offshore = 1
							select @MCADHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MCAD' and Hourly = 1
 
							select @MSDBAOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MSDBA' and Onshore = 1
							select @MSDBAOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MSDBA' and Offshore = 1
							select @MSDBAHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'MS MSDBA' and Hourly = 1

							select @SCJPOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCJP' and Onshore = 1
							select @SCJPOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCJP' and Offshore = 1
							select @SCJPHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCJP' and Hourly = 1

							select @SCJDOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCJD' and Onshore = 1
							select @SCJDOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCJD' and Offshore = 1
							select @SCJDHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCJD' and Hourly = 1

							select @SCEAOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCEA' and Onshore = 1
							select @SCEAOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCEA' and Offshore = 1
							select @SCEAHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Sun SCEA' and Hourly = 1

							select @OCP9IOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle OCP9I' and Onshore = 1
							select @OCP9IOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle OCP9I' and Offshore = 1
							select @OCP9IHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
							NewBillingType = 'Oracle OCP9I' and Hourly = 1

							select @OCP10IOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle OCP10I' and Onshore = 1
							select @OCP10IOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle OCP10I' and Offshore = 1
							select @OCP10IHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle OCP10I' and Hourly = 1
 
							select @SQLOnshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle SQL' and Onshore = 1
							select @SQLOffshore = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle SQL' and Offshore = 1
							select @SQLHourly = sum(isnull(Hours,0)) from #TEMP_IN
							where Prog_GroupID = @CurProg_GroupID and ProgramID = @CurProgramID and AFE_DescID = @CurAFE_DescID and 
								NewBillingType = 'Oracle SQL' and Hourly = 1
											
							--GET funding category and location combo  --		
							declare @@out_location varchar (100), @@out_fundingcat varchar (100), @@out_afenumber varchar (20), @@out_programmgr varchar (50), @@Total_FTE float
       						set @@out_fundingcat = NULL
       						set @@out_afenumber = NULL
							set @@out_programmgr = NULL
							set @@out_location = NULL
       						set @@Total_FTE = NULL
							exec GET_Location_Combo @CurAFE_DescID, @DateFrom, @DateTo, @@out_location OUTPUT, @@out_fundingcat OUTPUT, @@out_afenumber OUTPUT,@@out_programmgr OUTPUT, @@Total_FTE OUTPUT
               
							-- Update temporary output table #TEMP_OUT.        
							update #TEMP_OUT 
							set ITSABillingCat = @ITSABillingCat,
								fundingcat = @@out_fundingcat,
								AFENumber = @@out_afenumber,
								ProgramMgr = @@out_programmgr,	
								location = @@out_location,
								COApprovedFTEs = isnull(@@Total_FTE,0),
								MCSDOnshoreHours = isnull(@MCSDOnshore,0),
								MCSDOffshoreHours = isnull(@MCSDOffshore,0),
								MCSDHourlyHours = isnull(@MCSDHourly,0),
 								MCADOnshoreHours = isnull(@MCADOnshore,0),
								MCADOffshoreHours = isnull(@MCADOffshore,0),
								MCADHourlyHours = isnull(@MCADHourly,0),
 								MSDBAOnshoreHours = isnull(@MSDBAOnshore,0),
								MSDBAOffshoreHours = isnull(@MSDBAOffshore,0),
								MSDBAHourlyHours = isnull(@MSDBAHourly,0),
 								SCJPOnshoreHours = isnull(@SCJPOnshore,0),
								SCJPOffshoreHours = isnull(@SCJPOffshore,0),
								SCJPHourlyHours = isnull(@SCJPHourly,0),
 								SCJDOnshoreHours = isnull(@SCJDOnshore,0),
								SCJDOffshoreHours = isnull(@SCJDOffshore,0),
								SCJDHourlyHours = isnull(@SCJDHourly,0),
 								SCEAOnshoreHours = isnull(@SCEAOnshore,0),
								SCEAOffshoreHours = isnull(@SCEAOffshore,0),
								SCEAHourlyHours = isnull(@SCEAHourly,0),
 								OCP9IOnshoreHours = isnull(@OCP9IOnshore,0),
								OCP9IOffshoreHours = isnull(@OCP9IOffshore,0),
								OCP9IHourlyHours = isnull(@OCP9IHourly,0),
 								OCP10IOnshoreHours = isnull(@OCP10IOnshore,0),
								OCP10IOffshoreHours = isnull(@OCP10IOffshore,0),
 								OCP10IHourlyHours = isnull(@OCP10IOnshore,0),
								SQLOnshoreHours = isnull(@SQLOnshore,0),
								SQLOffshoreHours = isnull(@SQLOffshore,0),
								SQLHourlyHours = isnull(@SQLHourly,0)
							where AutoKey = @MaxAFEDesc				

						FETCH NEXT FROM AFEDesc_cursor INTO @CurAFEDesc, @CurAFE_DescID
						END    
					CLOSE AFEDesc_cursor
					DEALLOCATE AFEDesc_cursor

				------------------------------------------------------------------------------------

				FETCH NEXT FROM Program_cursor INTO @CurProgram, @CurProgramID, @CurCOBusinessLead
				END
			CLOSE Program_cursor
			DEALLOCATE Program_cursor
	
		------------------------------------------------------------------------------------

        -- Populate TotalHours Column for record type 30 (horizontal add up).
        update #TEMP_OUT 
		set TotalHours = isnull(MCSDOnshoreHours,0) + isnull(MCSDOffshoreHours,0) + isnull(MCSDHourlyHours,0) +
			isnull(MCADOnshoreHours,0) + isnull(MCADOffshoreHours,0) + isnull(MCADHourlyHours,0) +
			isnull(MSDBAOnshoreHours,0) + isnull(MSDBAOffshoreHours,0) + isnull(MSDBAHourlyHours,0) +
			isnull(SCJPOnshoreHours,0) + isnull(SCJPOffshoreHours,0) + isnull(SCJPHourlyHours,0) +
			isnull(SCJDOnshoreHours,0) + isnull(SCJDOffshoreHours,0) + isnull(SCJDHourlyHours,0) +
			isnull(SCEAOnshoreHours,0) + isnull(SCEAOffshoreHours,0) + isnull(SCEAHourlyHours,0) +
			isnull(OCP9IOnshoreHours,0) + isnull(OCP9IOffshoreHours,0) + isnull(OCP9IHourlyHours,0) +
			isnull(OCP10IOnshoreHours,0) + isnull(OCP10IOffshoreHours,0) + isnull(OCP10IHourlyHours,0) +
			isnull(SQLOnshoreHours,0) + isnull(SQLOffshoreHours,0) + isnull(SQLHourlyHours,0)
        where AutoKey > @MaxProgGroup and RecNumber = 30
        
		-- Populate ActualFTEs column for record type 30. 
		update #TEMP_OUT 
		set ActualFTEs = TotalHours/143.5 where AutoKey > @MaxProgGroup and RecNumber = 30
        
		-- Populate EDSVariance column for record type 30. 
		update #TEMP_OUT 
		set EDSVariance = ActualFTEs - COApprovedFTEs where AutoKey > @MaxProgGroup and RecNumber = 30
   
        -- Populate totals for 10 fields (vertical add up).
		-- Update total information for 10 fields (vertical add up)
        declare @MCSDOnshoreHours decimal(10,2), @MCSDOffshoreHours decimal(10,2), @MCSDHourlyHours decimal(10,2), 
				@MCADOnshoreHours decimal(10,2), @MCADOffshoreHours decimal(10,2), @MCADHourlyHours decimal(10,2), 
				@MSDBAOnshoreHours decimal(10,2), @MSDBAOffshoreHours decimal(10,2), @MSDBAHourlyHours decimal(10,2), 
				@SCJPOnshoreHours decimal(10,2), @SCJPOffshoreHours decimal(10,2), @SCJPHourlyHours decimal(10,2), 
				@SCJDOnshoreHours decimal(10,2), @SCJDOffshoreHours decimal(10,2), @SCJDHourlyHours decimal(10,2), 
				@SCEAOnshoreHours decimal(10,2), @SCEAOffshoreHours decimal(10,2), @SCEAHourlyHours decimal(10,2), 
				@OCP9IOnshoreHours decimal(10,2), @OCP9IOffshoreHours decimal(10,2), @OCP9IHourlyHours decimal(10,2), 
				@OCP10IOnshoreHours decimal(10,2), @OCP10IOffshoreHours decimal(10,2), @OCP10IHourlyHours decimal(10,2), 
				@SQLOnshoreHours decimal(10,2), @SQLOffshoreHours decimal(10,2), @SQLHourlyHours decimal(10,2), 
				@TotalHours decimal(10,2), @ActualFTEs decimal(10,2), @COApprovedFTEs decimal(10,2), @EDSVariance decimal(10,2)
        
		select  @TotalHours = sum(isnull(TotalHours,0)), @ActualFTEs = sum(isnull(ActualFTEs,0)), @COApprovedFTEs = sum(isnull(COApprovedFTEs,0)), @EDSVariance = sum(isnull(EDSVariance,0)),
				@MCSDOnshoreHours = sum(isnull(MCSDOnshoreHours,0)), @MCSDOffshoreHours = sum(isnull(MCSDOffshoreHours,0)), @MCSDHourlyHours = sum(isnull(MCSDHourlyHours,0)),
				@MCADOnshoreHours = sum(isnull(MCADOnshoreHours,0)), @MCADOffshoreHours = sum(isnull(MCADOffshoreHours,0)), @MCADHourlyHours = sum(isnull(MCADHourlyHours,0)),
				@MSDBAOnshoreHours = sum(isnull(MSDBAOnshoreHours,0)), @MSDBAOffshoreHours = sum(isnull(MSDBAOffshoreHours,0)), @MSDBAHourlyHours = sum(isnull(MSDBAHourlyHours,0)),
				@SCJPOnshoreHours = sum(isnull(SCJPOnshoreHours,0)), @SCJPOffshoreHours = sum(isnull(SCJPOffshoreHours,0)), @SCJPHourlyHours = sum(isnull(SCJPHourlyHours,0)),
				@SCJDOnshoreHours = sum(isnull(SCJDOnshoreHours,0)), @SCJDOffshoreHours = sum(isnull(SCJDOffshoreHours,0)), @SCJDHourlyHours = sum(isnull(SCJDHourlyHours,0)),
				@SCEAOnshoreHours = sum(isnull(SCEAOnshoreHours,0)), @SCEAOffshoreHours = sum(isnull(SCEAOffshoreHours,0)), @SCEAHourlyHours = sum(isnull(SCEAHourlyHours,0)),
				@OCP9IOnshoreHours = sum(isnull(OCP9IOnshoreHours,0)), @OCP9IOffshoreHours = sum(isnull(OCP9IOffshoreHours,0)), @OCP9IHourlyHours = sum(isnull(OCP9IHourlyHours,0)),
				@OCP10IOnshoreHours = sum(isnull(OCP10IOnshoreHours,0)), @OCP10IOffshoreHours = sum(isnull(OCP10IOffshoreHours,0)), @OCP10IHourlyHours = sum(isnull(OCP10IHourlyHours,0)),
				@SQLOnshoreHours = sum(isnull(SQLOnshoreHours,0)), @SQLOffshoreHours = sum(isnull(SQLOffshoreHours,0)), @SQLHourlyHours = sum(isnull(SQLHourlyHours,0))
        from #TEMP_OUT where AutoKey > @MaxProgGroup

        update #TEMP_OUT
        set TotalHours = @TotalHours, ActualFTEs = @ActualFTEs, COApprovedFTEs = @COApprovedFTEs, EDSVariance = @EDSVariance,
			MCSDOnshoreHours = @MCSDOnshoreHours, MCSDOffshoreHours = @MCSDOffshoreHours, MCSDHourlyHours = @MCSDHourlyHours,
			MCADOnshoreHours = @MCADOnshoreHours, MCADOffshoreHours = @MCADOffshoreHours, MCADHourlyHours = @MCADHourlyHours,
			MSDBAOnshoreHours = @MSDBAOnshoreHours, MSDBAOffshoreHours = @MSDBAOffshoreHours, MSDBAHourlyHours = @MSDBAHourlyHours,
			SCJPOnshoreHours = @SCJPOnshoreHours, SCJPOffshoreHours = @SCJPOffshoreHours, SCJPHourlyHours = @SCJPHourlyHours,
			SCJDOnshoreHours = @SCJDOnshoreHours, SCJDOffshoreHours = @SCJDOffshoreHours, SCJDHourlyHours = @SCJDHourlyHours,
			SCEAOnshoreHours = @SCEAOnshoreHours, SCEAOffshoreHours = @SCEAOffshoreHours, SCEAHourlyHours = @SCEAHourlyHours,
			OCP9IOnshoreHours = @OCP9IOnshoreHours, OCP9IOffshoreHours = @OCP9IOffshoreHours, OCP9IHourlyHours = @OCP9IHourlyHours,
			OCP10IOnshoreHours = @OCP10IOnshoreHours, OCP10IOffshoreHours = @OCP10IOffshoreHours, OCP10IHourlyHours = @OCP10IHourlyHours,
			SQLOnshoreHours = @SQLOnshoreHours, SQLOffshoreHours = @SQLOffshoreHours, SQLHourlyHours = @SQLHourlyHours
        where AutoKey = @MaxProgGroup		
     		
		FETCH NEXT FROM ProgramGroup_cursor INTO @CurProgramGroup, @CurProg_GroupID
		END
	CLOSE ProgramGroup_cursor
	DEALLOCATE ProgramGroup_cursor

	----------------------------------------------------------------------------------------------------------------------

	-- Populate the 0 and 3 records.
	select  @TotalHours = sum(isnull(TotalHours,0)), @COApprovedFTEs = sum(isnull(COApprovedFTEs,0)),
		@MCSDOnshoreHours = sum(isnull(MCSDOnshoreHours,0)), @MCSDOffshoreHours = sum(isnull(MCSDOffshoreHours,0)), @MCSDHourlyHours = sum(isnull(MCSDHourlyHours,0)),
		@MCADOnshoreHours = sum(isnull(MCADOnshoreHours,0)), @MCADOffshoreHours = sum(isnull(MCADOffshoreHours,0)), @MCADHourlyHours = sum(isnull(MCADHourlyHours,0)),
		@MSDBAOnshoreHours = sum(isnull(MSDBAOnshoreHours,0)), @MSDBAOffshoreHours = sum(isnull(MSDBAOffshoreHours,0)), @MSDBAHourlyHours = sum(isnull(MSDBAHourlyHours,0)),
		@SCJPOnshoreHours = sum(isnull(SCJPOnshoreHours,0)), @SCJPOffshoreHours = sum(isnull(SCJPOffshoreHours,0)), @SCJPHourlyHours = sum(isnull(SCJPHourlyHours,0)),
		@SCJDOnshoreHours = sum(isnull(SCJDOnshoreHours,0)), @SCJDOffshoreHours = sum(isnull(SCJDOffshoreHours,0)), @SCJDHourlyHours = sum(isnull(SCJDHourlyHours,0)),
		@SCEAOnshoreHours = sum(isnull(SCEAOnshoreHours,0)), @SCEAOffshoreHours = sum(isnull(SCEAOffshoreHours,0)), @SCEAHourlyHours = sum(isnull(SCEAHourlyHours,0)),
		@OCP9IOnshoreHours = sum(isnull(OCP9IOnshoreHours,0)), @OCP9IOffshoreHours = sum(isnull(OCP9IOffshoreHours,0)), @OCP9IHourlyHours = sum(isnull(OCP9IHourlyHours,0)),
		@OCP10IOnshoreHours = sum(isnull(OCP10IOnshoreHours,0)), @OCP10IOffshoreHours = sum(isnull(OCP10IOffshoreHours,0)), @OCP10IHourlyHours = sum(isnull(OCP10IHourlyHours,0)),
		@SQLOnshoreHours = sum(isnull(SQLOnshoreHours,0)), @SQLOffshoreHours = sum(isnull(SQLOffshoreHours,0)), @SQLHourlyHours = sum(isnull(SQLHourlyHours,0))
	from #TEMP_OUT where RecNumber = 10

	update #TEMP_OUT set TotalHours = @TotalHours, COApprovedFTEs = @COApprovedFTEs, 
		MCSDOnshoreHours = @MCSDOnshoreHours, MCSDOffshoreHours = @MCSDOffshoreHours, MCSDHourlyHours = @MCSDHourlyHours, 
		MCADOnshoreHours = @MCADOnshoreHours, MCADOffshoreHours = @MCADOffshoreHours, MCADHourlyHours = @MCADHourlyHours,
		MSDBAOnshoreHours = @MSDBAOnshoreHours, MSDBAOffshoreHours = @MSDBAOffshoreHours, MSDBAHourlyHours = @MSDBAHourlyHours,
		SCJPOnshoreHours = @SCJPOnshoreHours, SCJPOffshoreHours = @SCJPOffshoreHours, SCJPHourlyHours = @SCJPHourlyHours,
		SCJDOnshoreHours = @SCJDOnshoreHours, SCJDOffshoreHours = @SCJDOffshoreHours, SCJDHourlyHours = @SCJDHourlyHours,
		SCEAOnshoreHours = @SCEAOnshoreHours, SCEAOffshoreHours = @SCEAOffshoreHours, SCEAHourlyHours = @SCEAHourlyHours,
		OCP9IOnshoreHours = @OCP9IOnshoreHours, OCP9IOffshoreHours = @OCP9IOffshoreHours, OCP9IHourlyHours = @OCP9IHourlyHours,
		OCP10IOnshoreHours = @OCP10IOnshoreHours, OCP10IOffshoreHours = @OCP10IOffshoreHours, OCP10IHourlyHours = @OCP10IHourlyHours,
		SQLOnshoreHours = @SQLOnshoreHours, SQLOffshoreHours = @SQLOffshoreHours, SQLHourlyHours = @SQLHourlyHours
	where RecNumber = 0

	update #TEMP_OUT set TotalHours = @TotalHours/143.5, ActualFTEs = @TotalHours/143.5, COApprovedFTEs = @COApprovedFTEs,
		MCSDOnshoreHours = @MCSDOnshoreHours/143.5, MCSDOffshoreHours = @MCSDOffshoreHours/143.5, MCSDHourlyHours = @MCSDHourlyHours/143.5,
		MCADOnshoreHours = @MCADOnshoreHours/143.5, MCADOffshoreHours = @MCADOffshoreHours/143.5, MCADHourlyHours = @MCADHourlyHours/143.5,
		MSDBAOnshoreHours = @MSDBAOnshoreHours/143.5, MSDBAOffshoreHours = @MSDBAOffshoreHours/143.5, MSDBAHourlyHours = @MSDBAHourlyHours/143.5,
		SCJPOnshoreHours = @SCJPOnshoreHours/143.5, SCJPOffshoreHours = @SCJPOffshoreHours/143.5, SCJPHourlyHours = @SCJPHourlyHours/143.5,
		SCJDOnshoreHours = @SCJDOnshoreHours/143.5, SCJDOffshoreHours = @SCJDOffshoreHours/143.5, SCJDHourlyHours = @SCJDHourlyHours/143.5,
		SCEAOnshoreHours = @SCEAOnshoreHours/143.5, SCEAOffshoreHours = @SCEAOffshoreHours/143.5, SCEAHourlyHours = @SCEAHourlyHours/143.5,
		OCP9IOnshoreHours = @OCP9IOnshoreHours/143.5, OCP9IOffshoreHours = @OCP9IOffshoreHours/143.5, OCP9IHourlyHours = @OCP9IHourlyHours/143.5,
		OCP10IOnshoreHours = @OCP10IOnshoreHours/143.5, OCP10IOffshoreHours = @OCP10IOffshoreHours/143.5, OCP10IHourlyHours = @OCP10IHourlyHours/143.5,
		SQLOnshoreHours = @SQLOnshoreHours/143.5, SQLOffshoreHours = @SQLOffshoreHours/143.5, SQLHourlyHours = @SQLHourlyHours/143.5
	where RecNumber = 3

	update #TEMP_OUT 
	set ActualFTEs = @TotalHours/143.5 where RecNumber = 0

	update #TEMP_OUT 
	set EDSVariance = ActualFTEs - COApprovedFTEs where RecNumber in (0,3)

	--update #TEMP_OUT set ExpectedMTDFTE = COApprovedFTEs * @Factor where COApprovedFTEs is not NULL
	--update #TEMP_OUT set VarianceMTDFTE = ActualFTEs - ExpectedMTDFTE where COApprovedFTEs is not NULL

	----------------------------------------------------------------------------------------------------------------------

	No_Data_To_Process:
	SET NOCOUNT OFF

	If ( @OutputTable is NULL )
		Select RecNumber, RecType, RecDesc, RecTypeID, ITSABillingCat, FundingCat, AFENumber, COBusinessLead, Programmgr, Location, TotalHours, ActualFTEs, COApprovedFTEs, EDSVariance,
			MCSDOnshoreHours, MCSDOffshoreHours, MCSDHourlyHours, MCADOnshoreHours, MCADOffshoreHours, MCADHourlyHours, 
			MSDBAOnshoreHours, MSDBAOffshoreHours, MSDBAHourlyHours, SCJPOnshoreHours, SCJPOffshoreHours, SCJPHourlyHours, 
			SCJDOnshoreHours, SCJDOffshoreHours, SCJDHourlyHours, SCEAOnshoreHours, SCEAOffshoreHours, SCEAHourlyHours, 
			OCP9IOnshoreHours, OCP9IOffshoreHours, OCP9IHourlyHours, OCP10IOnshoreHours, OCP10IOffshoreHours, OCP10IHourlyHours, SQLOnshoreHours, SQLOffshoreHours, SQLHourlyHours,
			R10_ProgramGroup, R20_Program
		from #TEMP_OUT order by AutoKey		
	else 
	begin
	    -- Order by AutoKey will be included in the calling
	    set @SQL_statement = 'Select * into '+@OutputTable+' from #TEMP_OUT'
	    exec (@SQL_statement)
	end
