Use PIV_Reports

ALTER TABLE tblProject
DROP COLUMN AFENumber