Use PIV_Reports

ALTER TABLE lkProgram
DROP COLUMN COBusinessLead